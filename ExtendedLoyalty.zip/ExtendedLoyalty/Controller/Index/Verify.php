<?php
 
namespace Rinuu\ExtendedLoyalty\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Verify extends \Magento\Framework\App\Action\Action
{
	protected $_session;
	
    public function __construct(
		\Magento\Customer\Model\Session $session,
        Context $context
    )
    {
		$this->_session = $session;
        parent::__construct($context);
    }
 
    public function execute()
    {
		$result = [];
		if ($this->_session->isLoggedIn()) {
			$token = 'aG4gFhxO1RjWeyFwhoLa66B8x7asf9VGtrYy82jxnV8k';
			$email = $this->_session->getCustomer()->getEmail();
			$data = ['token' => $token, 'email' => $email];
			$options = [CURLOPT_URL => "http://insiders.rinuu.com/api/user/verify", CURLOPT_RETURNTRANSFER => true, CURLOPT_HEADER => false, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $data];
            $ch = curl_init();
			curl_setopt_array($ch, $options);
            $response = curl_exec($ch);
            if (!$response) {
				$result['hasErrors'] = true;
				$result['error'] = curl_error($ch);
            } else {
				$jsonData = json_decode($response,true);
				if ($jsonData && is_array($jsonData) && isset($jsonData['balance']) ) {
					$result['balance'] = $jsonData['balance'];
				} else {
					$result['askjoin'] = true;
				}
			}
            curl_close($ch);
		} else {
			$result['hasErrors'] = true;
			$result['error'] = __('Please Log in');
		}
		echo json_encode($result);
		exit;
    }
}