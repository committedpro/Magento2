<?php
 
namespace Rinuu\ExtendedLoyalty\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Create extends \Magento\Framework\App\Action\Action
{
	protected $_session;
	
    public function __construct(
		\Magento\Customer\Model\Session $session,
        Context $context
    )
    {
		$this->_session = $session;
        parent::__construct($context);
    }
 
    public function execute()
    {
		$result = [];
		if ($this->_session->isLoggedIn()) {
			$email = $this->_session->getCustomer()->getEmail();
			$name = $this->_session->getCustomer()->getFirstname().' '.$this->_session->getCustomer()->getLastname();
			$password = trim($this->getRequest()->getParam('password'));
			$password = urldecode($password);
			$data = ['name' => $name, 'email' => $email, 'password' => $password];

			$options = [CURLOPT_URL => "http://insiders.rinuu.com/api/user/create", CURLOPT_RETURNTRANSFER => true, CURLOPT_HEADER => false, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $data];
            $ch = curl_init();
			curl_setopt_array($ch, $options);
            $response = curl_exec($ch);
            if (!$response) {
				$result['hasErrors'] = true;
				$result['error'] = curl_error($ch);
            } else {
				$jsonData = json_decode($response,true);
				if ($jsonData && is_array($jsonData)){
					if(isset($jsonData['id']) ) {
						$result['balance'] = 0;
					}
					else if(isset($jsonData['error']) ) {
						$result['hasErrors'] = true;
						$result['error'] = $jsonData['error'];
					}
				} else {
					$result['hasErrors'] = true;
					$result['error'] = __('Unknown Error');
				}
			}
            curl_close($ch);
		} else {
			$result['hasErrors'] = true;
			$result['error'] = __('Please Log in');
		}
		echo json_encode($result);
		exit;
    }
}