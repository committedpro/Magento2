<?php
 
namespace Rinuu\ExtendedLoyalty\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Magento\Customer\Model\Session;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Framework\Exception\EmailNotConfirmedException;
use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\State\UserLockedException;
 
class Login extends \Magento\Framework\App\Action\Action
{
	protected $customerAccountManagement;
	protected $session;
	private $cookieMetadataFactory;
    private $cookieMetadataManager;
	
    public function __construct(
		Context $context,
        Session $customerSession,
        AccountManagementInterface $customerAccountManagement
    )
    {
		$this->session = $customerSession;
        $this->customerAccountManagement = $customerAccountManagement;
        parent::__construct($context);
    }
	
	private function getCookieManager()
    {
        if (!$this->cookieMetadataManager) {
            $this->cookieMetadataManager = \Magento\Framework\App\ObjectManager::getInstance()->get(
                \Magento\Framework\Stdlib\Cookie\PhpCookieManager::class
            );
        }
        return $this->cookieMetadataManager;
    }

    /**
     * Retrieve cookie metadata factory
     *
     * @deprecated
     * @return \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory
     */
    private function getCookieMetadataFactory()
    {
        if (!$this->cookieMetadataFactory) {
            $this->cookieMetadataFactory = \Magento\Framework\App\ObjectManager::getInstance()->get(
                \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory::class
            );
        }
        return $this->cookieMetadataFactory;
    }
 
    public function execute()
    {
		$result = [];
		if ($this->session->isLoggedIn()) {
			$email = $this->session->getCustomer()->getEmail();
			$password = trim($this->getRequest()->getParam('password'));
			$password = urldecode($password);
			try {
				$customer = $this->customerAccountManagement->authenticate($email, $password);
				$result['success'] = true;
				$this->session->setCustomerDataAsLoggedIn($customer);
				$this->session->regenerateId();
				if ($this->getCookieManager()->getCookie('mage-cache-sessid')) {
					$metadata = $this->getCookieMetadataFactory()->createCookieMetadata();
					$metadata->setPath('/');
					$this->getCookieManager()->deleteCookie('mage-cache-sessid', $metadata);
				}
			} catch (EmailNotConfirmedException $e) {
				$message = __('This account is not confirmed');
				$result['hasErrors'] = true;
				$result['error'] = $message;
			} catch (UserLockedException $e) {
				$message = __('The account is locked. ');
				$result['hasErrors'] = true;
				$result['error'] = $message;
			} catch (AuthenticationException $e) {
				$message = __('Invalid login or password.');
				$result['hasErrors'] = true;
				$result['error'] = $message;
			} catch (LocalizedException $e) {
				$message = $e->getMessage();
				$result['hasErrors'] = true;
				$result['error'] = $message;
			} catch (\Exception $e) {
				$message = __('An unspecified error occurred.');
				$result['hasErrors'] = true;
				$result['error'] = $message;
			}
		} else {
			$result['hasErrors'] = true;
			$result['error'] = __('Please Log in');
		}
		echo json_encode($result);
		exit;
    }
}