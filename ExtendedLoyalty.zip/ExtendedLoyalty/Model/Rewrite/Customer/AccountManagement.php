<?php
namespace Rinuu\ExtendedLoyalty\Model\Rewrite\Customer;

use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Framework\Exception\MailException;
use Magento\Customer\Model\EmailNotificationInterface;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\State\InputMismatchException;
use Magento\Framework\Exception\LocalizedException;

class AccountManagement extends \Magento\Customer\Model\AccountManagement
{
	public function createAccountNew(CustomerInterface $customer, $password = null, $redirectUrl = '')
    {
        if ($password !== null) {
            $this->checkPasswordStrength($password);
            $hash = $this->createPasswordHash($password);
        } else {
            $hash = null;
        }
        return $this->createAccountWithPasswordHashNew($customer, $hash, $redirectUrl);
    }

    public function createAccountWithPasswordHashNew(CustomerInterface $customer, $hash, $redirectUrl = '')
    {
        if ($customer->getId()) {
            $customer = $this->getCustomerRepository()->get($customer->getEmail());
            $websiteId = $customer->getWebsiteId();

            if ($this->isCustomerInStore($websiteId, $customer->getStoreId())) {
                throw new InputException(__('This customer already exists in this store.'));
            }
        }

        if (!$customer->getStoreId()) {
            if ($customer->getWebsiteId()) {
                $storeId = $this->getStoreManager()->getWebsite($customer->getWebsiteId())->getDefaultStore()->getId();
            } else {
                $storeId = $this->getStoreManager()->getStore()->getId();
            }
            $customer->setStoreId($storeId);
        }

        if (!$customer->getWebsiteId()) {
            $websiteId = $this->getStoreManager()->getStore($customer->getStoreId())->getWebsiteId();
            $customer->setWebsiteId($websiteId);
        }

        if ($customer->getId() === null) {
            $storeName = $this->getStoreManager()->getStore($customer->getStoreId())->getName();
            $customer->setCreatedIn($storeName);
        }

        $customerAddresses = $customer->getAddresses() ?: [];
        $customer->setAddresses(null);
        try {
            $customer = $this->getCustomerRepository()->save($customer, $hash);
        } catch (AlreadyExistsException $e) {
            throw new InputMismatchException(
                __('A customer with the same email already exists in an associated website.')
            );
        } catch (LocalizedException $e) {
            throw $e;
        }
        try {
            foreach ($customerAddresses as $address) {
                 if ($address->getId()) {
                    $newAddress = clone $address;
                    $newAddress->setId(null);
                    $newAddress->setCustomerId($customer->getId());
                    $this->getAddressRepository()->save($newAddress);
                 } else {
                    $address->setCustomerId($customer->getId());
                    $this->getAddressRepository()->save($address);
                }
            }
        } catch (InputException $e) {
            $this->getCustomerRepository()->delete($customer);
            throw $e;
        }
        $customer = $this->getCustomerRepository()->getById($customer->getId());
        $newLinkToken = $this->getMathRandom()->getUniqueHash();
        $this->changeResetPasswordLinkToken($customer, $newLinkToken);
        $this->sendEmailConfirmationNew($customer, $redirectUrl);

        return $customer;
    }
	
	public function sendEmailConfirmationNew(CustomerInterface $customer, $redirectUrl)
    {
		try {
			$hash = $this->getCustomerRegistry()->retrieveSecureData($customer->getId())->getPasswordHash();
			$templateType = self::NEW_ACCOUNT_EMAIL_REGISTERED;
			if ($this->isConfirmationRequired($customer) && $hash != '') {
				$templateType = self::NEW_ACCOUNT_EMAIL_CONFIRMATION;
			} elseif ($hash == '') {
				$templateType = self::NEW_ACCOUNT_EMAIL_REGISTERED_NO_PASSWORD;
			}
			$this->getEmailNotification()->newAccount($customer, $templateType, $redirectUrl, $customer->getStoreId());
		} catch (MailException $e) {
			$this->logger->critical($e);
		}
    }
	
    public function sendEmailConfirmation(CustomerInterface $customer, $redirectUrl)
    {
		if(!empty($redirectUrl)) {
			try {
				$hash = $this->getCustomerRegistry()->retrieveSecureData($customer->getId())->getPasswordHash();
				$templateType = self::NEW_ACCOUNT_EMAIL_REGISTERED;
				if ($this->isConfirmationRequired($customer) && $hash != '') {
					$templateType = self::NEW_ACCOUNT_EMAIL_CONFIRMATION;
				} elseif ($hash == '') {
					$templateType = self::NEW_ACCOUNT_EMAIL_REGISTERED_NO_PASSWORD;
				}
				$this->getEmailNotification()->newAccount($customer, $templateType, $redirectUrl, $customer->getStoreId());
			} catch (MailException $e) {
				$this->logger->critical($e);
			}
		}
    }
	
	private function getCustomerRepository()
    {
		return \Magento\Framework\App\ObjectManager::getInstance()->get(
			\Magento\Customer\Api\CustomerRepositoryInterface::class
		);
    }
	
	private function getMathRandom()
    {
		return \Magento\Framework\App\ObjectManager::getInstance()->get(
			\Magento\Framework\Math\Random::class
		);
    }
	
	private function getStoreManager()
    {
		return \Magento\Framework\App\ObjectManager::getInstance()->get(
			\Magento\Store\Model\StoreManagerInterface::class
		);
    }
	
	private function getAddressRepository()
    {
		return \Magento\Framework\App\ObjectManager::getInstance()->get(
			\Magento\Customer\Api\AddressRepositoryInterface::class
		);
    }
	
	private function getCustomerRegistry()
    {
		return \Magento\Framework\App\ObjectManager::getInstance()->get(
			\Magento\Customer\Model\CustomerRegistry::class
		);
    }
	
	private function getEmailNotification()
    {
		return \Magento\Framework\App\ObjectManager::getInstance()->get(
			EmailNotificationInterface::class
		);
    }
	
	public function changePassword($email, $currentPassword, $newPassword)
    {
		$isPasswordChanged = parent::changePassword($email,$currentPassword,$newPassword);
		if($isPasswordChanged) {
			$data = ['email' => $email, 'current_password' => $currentPassword, 'new_password' => $newPassword];
			$options = [CURLOPT_URL => "http://insiders.rinuu.com/api/user/password", CURLOPT_RETURNTRANSFER => true, CURLOPT_HEADER => false, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $data];
            $ch = curl_init();
			curl_setopt_array($ch, $options);
            $response = curl_exec($ch);
            curl_close($ch);
        }
        return $isPasswordChanged;
    }
}
