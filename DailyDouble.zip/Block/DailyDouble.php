<?php
namespace Rinuu\DailyDouble\Block;


use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\View\Element\Template;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Stdlib\DateTime\Timezone;
use Rinuu\DailyDouble\Helper\Data as DailyDoubleHelper;

class DailyDouble extends Template
{
    protected $storeManager;
	protected $helper;
	protected $timezone;

	protected $_template='Rinuu_DailyDouble::dailydouble.phtml';

    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
		DailyDoubleHelper $helper,
		Timezone $timezone,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->storeManager = $storeManager;
		$this->helper = $helper;
		$this->timezone = $timezone;
    }
	
	public function getHelper()
	{
		return $this->helper;
	}
	
	public function getTimer()
	{
		return $this->timezone;
	}
	
	public function getRemainingSeconds()
	{
		$hours = $this->timezone->date()->format('G');
		$minutes = (int)$this->timezone->date()->format('i');
		$seconds = (int)$this->timezone->date()->format('s');
		$totalSecondsElapsed = ($hours * 60 * 60) + ($minutes * 60) + $seconds;
		$totalSecondsRemaining = (24 * 60 * 60) - $totalSecondsElapsed;
		return $totalSecondsRemaining;
	}
	
	public function getProduct()
	{
		$today = $this->timezone->date()->format('Y-m-d');
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$collection = $objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Collection')
                                                  ->addAttributeToSelect(['name', 'price', 'image','sku'])
                                                  ->addAttributeToFilter('is_daily_double', 1)
												  ->addAttributeToFilter('daily_double_show_date', $today)
                                                  ->setPageSize(1,1);
		if ($collection->getSize() > 0) {
			foreach($collection as $product) {
				return $product;
			}
		}
		return false;
	}
}