<?php
 
namespace Rinuu\DailyDouble\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\Stdlib\DateTime\Timezone;

class getRemainingTime extends \Magento\Framework\App\Action\Action
{
	protected $timezone;
	
    public function __construct(
        Context $context,
		Timezone $timezone
    )
    {
        parent::__construct($context);
		$this->timezone = $timezone;
    }
 
    public function execute()
    {
		$hours = $this->timezone->date()->format('G');
		$minutes = (int)$this->timezone->date()->format('i');
		$seconds = (int)$this->timezone->date()->format('s');
		$totalSecondsElapsed = ($hours * 60 * 60) + ($minutes * 60) + $seconds;
		$totalSecondsRemaining = (24 * 60 * 60) - $totalSecondsElapsed;
		echo $totalSecondsRemaining;
    }
}