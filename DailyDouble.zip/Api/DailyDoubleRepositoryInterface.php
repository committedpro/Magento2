<?php
namespace Rinuu\DailyDouble\Api;

interface DailyDoubleRepositoryInterface
{
	/**
     * Update DailyDouble of a Product
     *
     * @param string $sku
     * @param int $status
	 * @param string $date
     * @return string
     */
    public function update($sku,$status,$date);
}
