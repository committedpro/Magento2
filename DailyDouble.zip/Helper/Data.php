<?php
namespace Rinuu\DailyDouble\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Framework\Pricing\Helper\Data as PriceHelper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	protected $priceHelper;
	
    public function __construct(
		Context $context,
		PriceHelper $priceHelper
	)
    {
        parent::__construct($context);
		$this->priceHelper = $priceHelper;
    }
    public function getStoreConfig($path)
    {
        return $this->scopeConfig->getValue(
            $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
	
	public function getProductPrice($price)
	{
		return $this->priceHelper->currency($price, true, false);
	}
}
