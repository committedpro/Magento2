<?php
namespace Rinuu\DailyDouble\Model;

use Rinuu\DailyDouble\Api\DailyDoubleRepositoryInterface;
use Magento\Catalog\Model\ResourceModel\Product\Collection;

class DailyDoubleRepository implements DailyDoubleRepositoryInterface
{
	protected $productFactory;
	protected $resourceModel;
	
	public function __construct(
		\Magento\Catalog\Model\ProductFactory $productFactory,
		\Magento\Catalog\Model\ResourceModel\Product $resourceModel
	)
    {
		$this->productFactory = $productFactory;
        $this->resourceModel = $resourceModel;
    }

    public function update($sku,$status,$date)
	{
		$response = [];
		try {
			if(empty($sku)) {
				throw new \Exception('Sku is required field');
			}
			if(empty($status)) {
				throw new \Exception('Status is required field');
			}
			if( !($status == 1 || $status == 0) ){
				throw new \Exception('Invalid Status. It should be either 0 or 1');
			}
			if(empty($date)) {
				throw new \Exception('Date is required field');
			}
			
			$dates = explode('-',$date);
			if(strlen($dates[0]) != 4) {
				throw new \Exception('Invalid Date Year. It should be yyyy-mm-dd format');
			}
			
			if(strlen($dates[1]) != 2) {
				throw new \Exception('Invalid Date Month. It should be yyyy-mm-dd format');
			}
			
			if(intval($dates[1]) > 12) {
				throw new \Exception('Invalid Date Month. It should be yyyy-mm-dd format');
			}
			
			if(strlen($dates[2]) != 2) {
				throw new \Exception('Invalid Date Day. It should be yyyy-mm-dd format');
			}
			
			if(intval($dates[1]) > 31) {
				throw new \Exception('Invalid Date Day. It should be yyyy-mm-dd format');
			}
			
			$product = $this->productFactory->create();
			$product->setData('_edit_mode', true);
			$productId = $this->resourceModel->getIdBySku($sku);
			if (!$productId) {
				throw new \Exception('Requested product doesn\'t exist');
			}
			$product->load($productId);
			$product->setData('is_daily_double', $status);
			$product->setData('daily_double_show_date', $date);
			
			$validationResult = $this->resourceModel->validate($product);
			if (true !== $validationResult) {
				throw new \Exception(
					__('Invalid product data: %1', implode(',', $validationResult))
				);
			}
            $this->resourceModel->save($product);
			$response = ['status' => 'success'];
        } catch (\Exception $e) {
            $response = ['status' => 'error', 'message' => $e->getMessage()];
        }
		return json_encode($response);
    }
}
