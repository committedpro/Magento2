<?php
namespace TheBigSurf\WireUpdateHook\Model;

use TheBigSurf\WireUpdateHook\Api\SkuRepositoryInterface;

class SkuRepository implements SkuRepositoryInterface
{
    protected $_resource;
	
	public function __construct(\Magento\Framework\Model\ResourceModel\Db\Context $context, $resourcePrefix = null)
    {
        $this->transactionManager = $context->getTransactionManager();
        $this->_resource = $context->getResources();
    }

	/**
	 * get a list of all SKUs within Magento Store
	 * @return array $skus
	 */
    public function get() {
		$connection = $this->_resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
		$table = $connection->getTableName('catalog_product_entity');
		$result = $connection->fetchAll('SELECT sku FROM `'.$table.'`');
		
		$skus = array_column($result,'sku');
		return $skus;
    }

}