<?php
namespace TheBigSurf\WireUpdateHook\Api;

interface SkuRepositoryInterface
{
	 /**
     * Get Sku List
     * 
     * @return array
     */
    public function get();
}
