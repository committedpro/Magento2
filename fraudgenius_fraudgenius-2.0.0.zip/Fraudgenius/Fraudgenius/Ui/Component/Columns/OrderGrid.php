<?php
namespace Fraudgenius\Fraudgenius\Ui\Component\Columns;

use Fraudgenius\Fraudgenius\Helper;

class OrderGrid extends \Magento\Ui\Component\Listing\Columns\Column
{
    public function prepareDataSource(array $dataSource)
	{
		if (isset($dataSource['data']['items'])) {
			foreach ($dataSource['data']['items'] as &$item) {
				if ($this->getData('name') == 'fraud_score') {
					$fraudScore = $item[$this->getData('name')];
					$item[$this->getData('name')] = $this->getScore($fraudScore,$item['entity_id']);
				}
			}
		}
		return $dataSource;
	}
	
	public function getScore($fraudScore,$order_id)
	{
		if (!is_null($fraudScore))
		{
			if ($fraudScore < 0) {
				return '&nbsp;';
			}
				
			$title = "";
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$fraudgenius = $objectManager->create('Fraudgenius\Fraudgenius\Helper\Data');
			$score = $fraudgenius->getStoreConfig("fraudgenius/detection/score");
			if ($score > 0) {
				if ($fraudgenius->isBad($score, $fraudScore)) {
					$title = "<font color=\"red\">{$fraudScore}</font>" ;
				} else {
					$title =  "<font color=\"green\">{$fraudScore}</font>";
				}
			}
			
			if ($title) {
				return $this->fraudLink($order_id,$title);
			}

			return $fraudScore;
		}
		return "";
	}
	
	function fraudLink($id,$title)
	{
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$urlBuilder = $objectManager->get('Magento\Framework\UrlInterface');
		$url = $urlBuilder->getUrl(
						'fraudgenius/index/popup',
                        ['id' => $id]
				);
		$html = "<a href=\"#\" onclick=\"FraudgeniusAdminPopup('{$url}');\">" . $title . "</a>";
		return $html;
	}
 }
