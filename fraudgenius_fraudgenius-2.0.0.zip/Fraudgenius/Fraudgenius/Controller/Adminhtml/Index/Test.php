<?php 
namespace Fraudgenius\Fraudgenius\Controller\Adminhtml\Index; 
 
class Test extends \Magento\Framework\App\Action\Action {
    protected $resultPageFactory;
    public function __construct(\Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory)     {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
    public function execute()
    {
		/*$joins = [
			'fraudgenius' => [
				'table' => 'fraudgenius_score',
				'origin_column' => 'entity_id',
				'target_column' => 'order_id',
			],
		];
		
		$columns = [
			'fraud_score' => 'fraudgenius.fraud_score',
			'entity_id' => 'sales_order.entity_id'
		];
		
		$args = [
			'context' => $this->_objectManager->get('Magento\Framework\Model\ResourceModel\Db\Context'),
			'mainTableName' => 'sales_order',
			'gridTableName' => 'sales_order_grid',
			'orderIdField' => 'entity_id',
			'joins' => $joins,
			'columns' => $columns
		];
		
		$orderGrid = $this->_objectManager->create('Magento\Sales\Model\ResourceModel\Grid', $args);
		$orderGrid->refresh(17);
		echo 'Grid Refreshed';
		exit;*/
		$helper = $this->_objectManager->get('Fraudgenius\Fraudgenius\Helper\Data');
		$merchantId = trim($helper->getStoreConfig('fraudgenius/account/merchantId'));
		$merchantKey = trim($helper->getStoreConfig('fraudgenius/account/merchantKey'));
		$forceIP = trim($helper->getStoreConfig('fraudgenius/account/forceIP'));
		$testMode = trim($helper->getStoreConfig('fraudgenius/account/testMode'));
		
		if ($merchantId == '' || $merchantKey == '') {
			echo '<font style="color:red">';
			echo 'Error: Your Merchant ID or Key is incorrect or missing, please enter the correct data and try again.';
			echo '</font>';
			exit();
		}
		
		$remoteAddress = $_SERVER["REMOTE_ADDR"];
		$params1 = $helper->getTestParams();
		$params2 = [
			'merchid' => $merchantId,
			'merchkey' => $merchantKey,
			'remoteip' => $forceIP ? $forceIP : $remoteAddress
		];
		
		if ($testMode) {
			$params3 = ['testtrans' => 1];
		} else {
			$params3 = [];
		}
		
		$params = array_merge($params1,$params2,$params3);
		
		$api = $this->_objectManager->get('\Fraudgenius\Fraudgenius\Model\Api');
		$ret = $api->fetch($params);
		if ($ret == -1) {
			echo '<font style="color:red">';
			echo $api->getErrorMsg();
			echo '</font>';
			exit();
		}
		echo '<font style="color:blue">Success: Fraud detection service is enabled and working.</font>';
		exit();
    }
}
