<?php 
namespace Fraudgenius\Fraudgenius\Controller\Adminhtml\Index;
 
class Reload extends \Magento\Framework\App\Action\Action {
    protected $resultPageFactory;
    public function __construct(\Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory)     {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
    public function execute()
    {
		try {
			$orderId = $this->getRequest()->getParam('id');
			if (!$orderId) {
				throw new Exception("Order not found");
			} else {
				$helper = $this->_objectManager->get('Fraudgenius\Fraudgenius\Helper\Data');
				$helper->saveFraudScore($orderId,1);
			}
		} catch(\Exception $e) {
			 $this->messageManager->addError($e->getMessage());
		}
		
		$resultRedirect = $this->resultRedirectFactory->create();
		return $resultRedirect->setPath('sales/order/view', ['order_id' => $orderId, 'active_tab' => 'fraudgenius']);
    }
}