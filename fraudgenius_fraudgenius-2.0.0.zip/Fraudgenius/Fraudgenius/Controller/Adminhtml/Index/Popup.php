<?php 
namespace Fraudgenius\Fraudgenius\Controller\Adminhtml\Index; 
 
class Popup extends \Magento\Framework\App\Action\Action {
    protected $resultPageFactory;
    public function __construct(\Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory)     {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
    public function execute()
    {
		$orderId = $this->getRequest()->getParam('id');
		if(!$orderId)
		{
			echo "Order not found";
			exit();
		}

		$helper = $this->_objectManager->get('Fraudgenius\Fraudgenius\Helper\Data');
		$merchantId = trim($helper->getStoreConfig('fraudgenius/account/merchantId'));
		$merchantKey = trim($helper->getStoreConfig('fraudgenius/account/merchantKey'));
		
		if(trim($merchantId) == '' || trim($merchantKey) == '')
		{
			echo 'Your Merchant ID or Key is incorrect or missing, please enter the correct data and try again.';
			exit();
		}
		
		$order = $this->_objectManager->get('Magento\Sales\Model\Order')->load($orderId);
		if(!$order || !$order->getId())
		{
			echo "Order not found";
			exit();
		}
		
		$fraudScore = $helper->getFraudScore($order->getId());
		if (!$fraudScore)
		{
			echo "No score yet.";
			exit();
		}
		
		$html = '<h2>Fraud Detection Redirecting...</h2>
			<form name="orderPopupForm" id="orderPopupForm" action="https://www.fraudgenius.com/process/orderdisp.php" method="post">
				<input type="hidden" name="transactionid" value="'.$fraudScore->getFraudTransId().'"/>
				<input type="hidden" name="merchid" value="'.trim($merchantId).'"/>
				<input type="hidden" name="merchkey" value="'.trim($merchantKey).'"/>
			</form>';
			
		$js = '<script type="text/javascript">document.orderPopupForm.submit();</script>';
		
        $html .= $js;

        echo $html;
		exit;
    }
}
