<?php
namespace Fraudgenius\Fraudgenius\Model;

use \Magento\Framework\Model\AbstractModel;

class Score extends AbstractModel
{
    const SCORE_ID = 'entity_id';

    protected $_eventPrefix = 'fraud';
    protected $_eventObject = 'score'; 
    protected $_idFieldName = self::SCORE_ID;
	
	protected function _construct()
    {
        $this->_init('Fraudgenius\Fraudgenius\Model\ResourceModel\Score');
    }
	
	public function loadByOrderId($order_id)
    {
        return $this->loadByAttribute('order_id', $order_id);
    }
	
	public function loadByAttribute($attribute, $value)
    {
        $this->load($value, $attribute);
        return $this;
    }
 }
