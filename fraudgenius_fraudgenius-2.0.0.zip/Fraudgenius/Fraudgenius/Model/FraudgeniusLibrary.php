<?php
namespace Fraudgenius\Fraudgenius\Model;

use Exception;

class FraudgeniusLibrary
{
	public $field_string;
	public $fields = array();
	
	public $response_string;
	public $response = array();
	
	public $gateway_url = "https://api.fraudgenius.com/api.php";
	
	public function add_field($field, $value)
	{
		$this->fields["$field"] = $value;   
	}

	public function getfraudscore()
	{
		foreach( $this->fields as $key => $value ) {
			$this->field_string .= "$key=" . urlencode( $value ) . "&";
		}
		 
		$this->field_string = rtrim( $this->field_string, "& " );
	  
		$ch = curl_init($this->gateway_url); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
		curl_setopt($ch, CURLOPT_HEADER, 0); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 300); 
		curl_setopt($ch, CURLOPT_POSTFIELDS, $this->field_string); 
		$this->response_string = urldecode(curl_exec($ch)); 
		if (curl_errno($ch))
		{
			$this->response['Message Text'] = curl_error($ch);
			return 3;
		}
		else
		{
			curl_close ($ch);
		}
		
		$temp_values = explode('|', $this->response_string);
		$temp_keys= array ( 
		   "Response Code", "Message Text", "Transaction ID", "Fraud Score"
		);
		for ($i=0; $i<sizeof($temp_keys);$i++)
		{
			$this->response["$temp_keys[$i]"] = $temp_values[$i];
		}
		return $this->response['Response Code'];
	}
	
	public function get_message_text() {
	  return $this->response['Message Text'];
	}
	
	public function get_response_score() {
	  return $this->response['Fraud Score'];
	}
   
	public function get_response_transid()
	{
		return $this->response['Transaction ID'];
	}

	public function dump_fields()
	{
      echo "<h3>fraudgenius_class->dump_fields() Output:</h3>";
      echo "<table width=\"95%\" border=\"1\" cellpadding=\"2\" cellspacing=\"0\">
            <tr>
               <td bgcolor=\"black\"><b><font color=\"white\">Field Name</font></b></td>
               <td bgcolor=\"black\"><b><font color=\"white\">Value</font></b></td>
            </tr>"; 
            
      foreach ($this->fields as $key => $value) {
         echo "<tr><td>$key</td><td>".urldecode($value)."&nbsp;</td></tr>";
      }
 
      echo "</table><br>"; 
   }

   public function dump_response()
   {
      echo "<h3>fraudgenius_class->dump_response() Output:</h3>";
      echo "<table width=\"95%\" border=\"1\" cellpadding=\"2\" cellspacing=\"0\">
            <tr>
               <td bgcolor=\"black\"><b><font color=\"white\">Index&nbsp;</font></b></td>
               <td bgcolor=\"black\"><b><font color=\"white\">Field Name</font></b></td>
               <td bgcolor=\"black\"><b><font color=\"white\">Value</font></b></td>
            </tr>";
            
      $i = 0;
      foreach ($this->response as $key => $value) {
         echo "<tr>
                  <td valign=\"top\" align=\"center\">$i</td>
                  <td valign=\"top\">$key</td>
                  <td valign=\"top\">$value&nbsp;</td>
               </tr>";
         $i++;
      } 
      echo "</table><br>";
   }
}
