<?php
namespace Fraudgenius\Fraudgenius\Model;

use \Magento\Framework\Model\AbstractModel;

class Rawdata extends AbstractModel
{
    const RAWDATA_ID = 'id';

    protected $_eventPrefix = 'fraud';
    protected $_eventObject = 'rawdata'; 
    protected $_idFieldName = self::RAWDATA_ID;
	
	protected function _construct()
    {
        $this->_init('Fraudgenius\Fraudgenius\Model\ResourceModel\Rawdata');
    }
	
	public function loadByQuoteId($order_id)
    {
        return $this->loadByAttribute('order_id', $order_id);
    }
	
	public function loadByAttribute($attribute, $value)
    {
        $this->load($value, $attribute);
        return $this;
    }
 }
