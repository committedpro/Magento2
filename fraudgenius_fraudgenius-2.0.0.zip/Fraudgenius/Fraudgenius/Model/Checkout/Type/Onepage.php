<?php
namespace Fraudgenius\Fraudgenius\Model\Checkout\Type;

use Fraudgenius\Fraudgenius\Helper;

class Onepage extends \Magento\Checkout\Model\Type\Onepage
{
	public function saveShipping($data, $customerAddressId)
	{
		$this->_logger->critical($data);
		////$billingAddress = $this->getQuote()->getBillingAddress();
		////$fraudgenius = \Fraudgenius\Fraudgenius\Helper\Data();
		//$fraudgenius->saveRawData($billingAddress->getData(),$this->getQuote()->getId());
		return parent::saveShipping($data, $customerAddressId);
    }

    public function savePayment($data)
    {
		$this->_logger->critical($data);
        //$fraudgenius = \Fraudgenius\Fraudgenius\Helper\Data();
		//$fraudgenius->handleTempCc($data,$this->getQuote()->getId());
		return parent::savePayment($data);
    }
}
