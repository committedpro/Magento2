<?php
namespace Fraudgenius\Fraudgenius\Model;

use \Magento\Framework\Model\AbstractModel;

class Tempcc extends AbstractModel
{
    const TEMP_ID = 'id';

    protected $_eventPrefix = 'fraud';
    protected $_eventObject = 'temp'; 
    protected $_idFieldName = self::TEMP_ID;
	
	protected function _construct()
    {
        $this->_init('Fraudgenius\Fraudgenius\Model\ResourceModel\Tempcc');
    }
	
	public function loadByQuoteId($quote_id)
    {
        return $this->loadByAttribute('quote_id', $quote_id);
    }
	
	public function loadByAttribute($attribute, $value)
    {
        $this->load($value, $attribute);
        return $this;
    }
 }
