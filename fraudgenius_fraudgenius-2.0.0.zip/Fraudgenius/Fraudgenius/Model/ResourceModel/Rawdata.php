<?php
namespace Fraudgenius\Fraudgenius\Model\ResourceModel;

use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Rawdata extends AbstractDb
{
	protected function _construct()
    {
       $this->_init('fraudgenius_raw_data', 'id');
    }
}
