<?php
namespace Fraudgenius\Fraudgenius\Model;

use Exception;

class Api
{
    protected $errorMsg = "";
	protected $errorCode = "";
	protected $lastMsg = "";
	protected $lastTransID = "";
	protected $lastFraudScore = 0;
	protected $lastRespone = "";
	
	public function getLastData()
	{
		$ret = array();
		$ret["fraud_score"] = $this->lastFraudScore ;
		$ret["fraud_msg"] = $this->lastMsg;
		$ret["fraud_respone"] = $this->lastRespone;
		$ret["fraud_trans_id"] = $this->lastTransID;
		return $ret;
	}
	public function getLastRespone()
	{
		return $this->lastRespone;
	}
	public function getLastTransID()
	{
		return $this->lastTransID;
	}
	public function getLastFraudScore()
	{
		return $this->lastFraudScore;
	}
	public function getLastMsg()
	{
		return $this->lastMsg;
	}
	public function getErrorCode()
	{
		return $this->errorCode;
	}
	public function getErrorMsg()
	{
		return $this->errorMsg;
	}
	public function getLastResult()
	{
		return $this->lastResult;
	}
	public function fetch($params)
	{
		if (!$this->validateParam($params))
		{
			$this->errorCode	= 101;
			$this->errorMsg	= "Invalid params";
			return -1;
		}
		$this->fraudApi = new FraudgeniusLibrary();
		foreach ($params as $key=>$val){
			$this->fraudApi->add_field($key,$val);
		}
		$proxyIp = $this->getProxyIp();
		$this->fraudApi->add_field('apiversion', '1.0');
		$this->fraudApi->add_field('acceptlang', $_SERVER['HTTP_ACCEPT_LANGUAGE']); 
		$this->fraudApi->add_field('agent', $_SERVER['HTTP_USER_AGENT']);  
		$this->fraudApi->add_field('accept', $_SERVER['HTTP_ACCEPT']);  
		$this->fraudApi->add_field('acceptencode', $_SERVER['HTTP_ACCEPT_ENCODING']);
		if ($proxyIp){
			$this->fraudApi->add_field('proxyip', $proxyIp);
		}
		$this->lastFraudScore = 0;
		$this->lastTransID = "";
		$this->lastMsg = "";
		$this->errorCode = "";
		$this->errorMsg = "";
		$this->lastRespone = "";
		$isError = 1;
		$ret = 0;
		$connectError = "";
		try {
			$this->fraudApi->response_string = "";
			$ret = $this->fraudApi->getfraudscore();
		} catch (Exception $e) {
			$connectError = $e->getMessage();
			$ret = 4;
		}
		switch ($ret) {
			case 1:
				$this->lastFraudScore = $this->fraudApi->get_response_score();
				$this->lastTransID = $this->fraudApi->get_response_transid();
				$this->lastMsg = $this->fraudApi->get_message_text();
				$isError = 0;
				break;
			case 2:
				$this->errorMsg = $this->fraudApi->get_message_text();
				$this->errorCode = 2;
				$this->lastTransID = $this->fraudApi->get_response_transid();
				break;
			case 3:
				$this->errorMsg = $this->fraudApi->get_message_text();
				$this->errorCode = 3;
				break;
			default:
				$this->errorMsg = "Can't conect [$connectError]";
				$this->errorCode = 4;
				break;
		}
		$this->lastRespone = $this->fraudApi->response_string;
		if ($isError) {
			return -1;
		}
		return 1;
	}
	public function validateParam($params)
	{
		if (!$params) {
			return 0;
		} else {
			return 1;
		}
	}
	public function getProxyIp()
	{
		$ip = "";
		foreach (array('HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED') as $key) {
			if (array_key_exists($key, $_SERVER) === true) {
				foreach (explode(',', $_SERVER[$key]) as $ip) {
					$ip = trim($ip);
					if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
						if ($ip != $_SERVER['REMOTE_ADDR']) {
							return $ip;
						}
					}
				}
			}
		}
		return "";
	}
}
