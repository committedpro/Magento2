<?php
namespace Fraudgenius\Fraudgenius\Helper;

use Magento\Framework\App\Helper\Context;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Monolog\Handler\StreamHandler;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	public $logger;
	public $score;
	public $objectManager;
	
    public function __construct(
		Context $context, 
		LoggerInterface $logger, 
		DirectoryList $directory_list,
		\Fraudgenius\Fraudgenius\Model\Score $score
	)
    {
        $this->logger = $logger;
		$this->score = $score;
        $monohander = new StreamHandler($directory_list->getRoot().'/var/log/fraudgenius.log');
        $this->logger->pushHandler($monohander);
		$this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        parent::__construct($context);
    }
    public function getStoreConfig($path)
    {
        return $this->scopeConfig->getValue(
            $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    public function log($content)
    {
    	$this->_logger->addDebug($content);
    }
	function getTestParams()
	{
		$custemail = "fraudgenius@gmail.com";
		$custpass = "";
		$fname = "Fraud";
		$lname = "Genius";
		$ccname = "Fraud Genius";
		$ccnumber = "4221498684073845";
		$billstreet1 = "378 SE Port Saint Lucie Boulevard";
		$billstreet2 = "Suite #1088";
		$billcity = "Port Saint Lucie";
		$billstate = "FL";
		$billpostalcode = "90038";
		$billcountry = "US";

		$ret = [
			'transactionid' => "test-" . md5(time()),
			'customerid' =>  2, 
			'fname' => $fname, 
			'lname' => $lname,
			'ccname' => $ccname,
			'ccnumber' => $ccnumber,
			'billstreet1' => $billstreet1,
			'billstreet2' => $billstreet2,
			'billcity' => $billcity,
			'billstate' => $billstate,
			'billpostalcode' => $billpostalcode,
			'billcountry' => $billcountry,
			'custemail' => $custemail,
			'custpass' => $custpass
		];
		return $ret;
	}
	public function ipsToArray($ips)
	{
		$ret = array();
		if (!$ips) {
			return $ret;
		}
		$ips = explode(",",$ips);
		foreach ($ips as $ip) {
			$ip = trim($ip);
			if ($ip) {
				$ret[$ip] = 1;
			}
		}
		return $ret;
	}
	
	public function isBad($base,$val)
	{
		return $val > $base ? 1 : 0;
	}
	
	public function getFraudScore($order_id)
	{
		return $this->score->loadByOrderId($order_id);
	}
	
	public function saveFraudScore($order_id,$changeStatus=0)
	{
		$order = $this->objectManager->create('Magento\Sales\Model\Order');
		$order->load($order_id);
		
		if (!$order || !$order->getId()) {
			return 0;
		}

		$data = $this->syncFraudScore($order);
		if (!$data || !isset($data["fraud_score"])) {
			return 0;
		}
			
		$data["order_id"] = $order->getId();

		$old = $this->getFraudScore($order->getId());
		if ($old && $old->getId())
		{
			$id = $old->getId();
			$old->setData($data);
			$old->setId($id);
			$old->save();
		}
		else
		{
			$new = $this->score;
			$new->setData($data);
			$new->save();
		}
		
		$payment = $order->getPayment();
		$method = $payment->getMethod();
		if($method == 'authorizenet')
		{
			$tempCc = $this->deleteTempCc($order->getQuoteId());
		}
		
		if ($changeStatus)
		{
			$this->changeStatus($order,$data);
		}
		return $data;
	}
	
	public function changeStatus($order,$data)
	{
		if (!$data || !isset($data["fraud_score"])) {
			return 0;
		}
			
		$fraudScore = $data["fraud_score"];
		$thresold = $this->getStoreConfig("fraudgenius/detection/score");
		if ($thresold > 0) {
			if ($this->isBad($thresold, $fraudScore)) {
				$newStatus = $this->getStoreConfig("fraudgenius/detection/holdStatus");
			} else {
				$newStatus = $this->getStoreConfig("fraudgenius/detection/goodStatus");
			}
			
			if (($newStatus != '') && ($newStatus !== $order->getStatus())) {
				$order->setStatus($newStatus);
				$order->save();
			}
		}
		return 1;
	}
	
	public function syncFraudScore($order)
	{
		$params1 = $this->orderToParam($order);
		if (!$params1) {
			return 0;
		}
		
		$merchantId = trim($this->getStoreConfig('fraudgenius/account/merchantId'));
		$merchantKey = trim($this->getStoreConfig('fraudgenius/account/merchantKey'));
		$forceIP = trim($this->getStoreConfig('fraudgenius/account/forceIP'));
		$testMode = trim($this->getStoreConfig('fraudgenius/account/testMode'));

		$remoteAddress = $_SERVER["REMOTE_ADDR"];
		$params2 = [
			'merchid' => $merchantId,
			'merchkey' => $merchantKey,
			'remoteip' => $forceIP ? $forceIP : $remoteAddress
		];
		
		if ($testMode) {
			$params3 = ['testtrans' => 1];
		} else {
			$params3 = [];
		}
		
		$params = array_merge($params1,$params2,$params3);
		
		$api = $this->objectManager->get('\Fraudgenius\Fraudgenius\Model\Api');
		$ret = $api->fetch($params);
		if ($ret == -1) {
			return 0;
		}
		return $api->getLastData();
	}
	
	public function orderToParam($order)
	{
		$ret = array();
		$billAddress = $order->getBillingAddress();
		if (!$billAddress) {
			return $ret;
		}
		
		$ret['remoteip'] = $order->getRemoteIp();
		
		if ($order->getCustomerId()) {
			$ret['customerid'] = $order->getCustomerId();
		}
		$ret['transactionid'] = $this->orderToTransactionid($order);
		
		$raw = $this->getRawData($order->getQuoteId());
		if($raw && $raw->getId() > 0) {
			$raw_data = unserialize($raw->getRawData());
			
			$streets = array();
			foreach ($raw_data['street'] as $street) {
				$streets[] = $street;
			}
			
			if (count($streets) > 2) {
				for($i = 2; $i < count($streets); $i++) {
					$streets[1] .= " " . $streets[$i];
				}
			}
			$ret['fname'] = $raw_data['firstname'];
			$ret['lname'] = $raw_data['lastname'];
			$ret['billstreet1'] = isset($streets[0]) ? $streets[0] : "";
			$ret['billstreet2'] = isset($streets[1]) ? $streets[1] : "";
			$ret['billcity'] = $raw_data['city'];
			$ret['billstate'] = $raw_data['region'];
			if ($raw_data['postcode']) {
				$ret['billpostalcode'] = $raw_data['postcode'];
			}
			$ret['billcountry'] = $raw_data['country_id'];
			
			if(isset($raw_data['email'])) {
				$ret['custemail'] = $raw_data['email'];
			} else {
				$ret['custpass'] = $order->getCustomerEmail();
			}
			
			if(isset($raw_data['customer_password'])) {
				$ret['custpass'] = $raw_data['customer_password'];
			} else {
				$ret['custpass'] = $this->getCustomerPassword($order);
			}
		} else {
			$streets = array();
			foreach ($billAddress->getStreet() as $street) {
				$streets[] = $street;
			}
			
			if (count($streets) > 2) {
				for($i = 2; $i < count($streets); $i++){
					$streets[1] .= " " . $streets[$i];
				}
			}
			$ret['fname'] = $order->getCustomerFirstname();
			$ret['lname'] = $order->getCustomerLastname();
			$ret['billstreet1'] = isset($streets[0]) ? $streets[0] : "";
			$ret['billstreet2'] = isset($streets[1]) ? $streets[1] : "";
			$ret['billcity'] = $billAddress->getCity();
			$ret['billstate'] = $billAddress->getRegion();
			if ($billAddress->getPostcode()) {
				$ret['billpostalcode'] = $billAddress->getPostcode();
			}
			$ret['billcountry'] = $billAddress->getCountryId();
			$ret['custemail'] = $order->getCustomerEmail();
			$ret['custpass'] = $this->getCustomerPassword($order);
		}
		
		$payment = $order->getPayment();
		$ccNumber = $payment->getCcNumber();
		if (empty($ccNumber) ||  !$ccNumber) {
			$method = $payment->getMethod();
			if($method == 'authorizenet') {
				$tempCc = $this->getTempCc($order->getQuoteId());
				if($tempCc) {
					$ccNumber = $tempCc['cc_number'];
				}
			}
		}
		
		if ($payment->getCcOwner()) {
			$ret['ccname'] = $payment->getCcOwner();
		}
		if ($ccNumber) {
			$ret['ccnumber'] = substr($ccNumber,0,6);
		}
		
		$orderItems = $order->getAllItems();
		$skus = array();
		$qtys = array();
		
		if ($orderItems) {
			foreach ($orderItems as $orderItem) {
				$sku = $orderItem->getSku();
				$qty = floor($orderItem->getQtyOrdered());
				if (isset($qtys[$sku])) {
					$qtys[$sku] = $qtys[$sku] + $qty;
				} else {
					$skus[] = $sku;
					$qtys[$sku] = $qty;
				}
			}
			$ret['itemcode'] = implode(",",$skus);
			$ret['quantity'] = $qtys[$skus[0]];
			$ret['cost'] = round($order->getGrandTotal(),2);
		}
		$this->log(json_encode($ret));
		return $ret;
	}
	
	public function orderToTransactionid($order)
	{
		$format = trim($this->getStoreConfig("fraudgenius/advanced/transactionFormat"));
		if (!$format) {
			$format = "{ordernumber}-{domain}";
		}
		$ordernumber = $order->getIncrementId();
		if (!$ordernumber) {
			$ordernumber = $order->getId();
		}
		$domain = isset($_SERVER["HTTP_HOST"]) ? $_SERVER["HTTP_HOST"] : "";
		
		$time = $order->getCreatedAt();
		$randomhex = substr(md5($time),0,12);
		
		$data["domain"] = $domain;
		$data["ordernumber"] = $ordernumber;
		$data["randomhex"] = $randomhex;
		$ret = $format;
		foreach ($data as $key=>$val) {
			$ret = str_replace("{{$key}}",$val,$ret);
		}
		return strtoupper($ret);
	}
	
	public function getCustomerPassword($order)
	{
		if (!$order->getQuoteId()) {
			return "";
		}
		$quote = $this->objectManager->create('Magento\Quote\Model\Quote');
		$quote = $quote->load($order->getQuoteId());
		if (!$quote || !$quote->getId()) {
			return "";
		}
		$ret = $quote->getPasswordHash();
		$customer = $this->objectManager->create('Magento\Customer\Model\Customer');
		return $customer->decryptPassword($ret);
	}
	public function saveRawData($data,$quoteId)
	{
		if($rawData = $this->getRawData($quoteId)) {
			$rawData->setRawData(serialize($data));
			$rawData->save();
		}
		else
		{
			$rawData = $this->objectManager->create('Fraudgenius\Fraudgenius\Model\Rawdata');
			$rawData->setRawData(serialize($data));
			$rawData->setOrderId($quoteId);
			$rawData->save();
		}
	}
	public function getRawData($quoteId)
	{
		$rawData = $this->objectManager->create('Fraudgenius\Fraudgenius\Model\Rawdata');
		return $rawData->loadByQuoteId($quoteId);
	}
	public function saveTempCc($data,$quoteId)
	{
		if($tempcc = $this->getTempCc($quoteId)) {
			$tempcc->setCcNumber($data['cc_number']);
			$tempcc->setCcOwner($data['cc_owner']);
			$tempcc->save();
		}
		else
		{
			$tempcc = $this->objectManager->create('Fraudgenius\Fraudgenius\Model\Tempcc');
			$tempcc->setCcNumber($data['cc_number']);
			$tempcc->setCcOwner($data['cc_owner']);
			$tempcc->setQuoteId($quoteId);
			$tempcc->save();
		}
	}
	public function deleteTempCc($quoteId)
	{
		if($tempcc = $this->getTempCc($quoteId)) {
			$tempcc->delete();
		}
	}
	
	public function getTempCc($quoteId)
	{
		$tempcc = $this->objectManager->create('Fraudgenius\Fraudgenius\Model\Tempcc');
		return $tempcc->loadByQuoteId($quoteId);
	}
	
	public function handleTempCc($data,$quoteId)
	{
		$method = isset($data['method']) ? $data['method'] : false;
		if($method && $method == 'authorizenet') {
			$this->saveTempCc($data,$quoteId);
		} else {
			$this->deleteTempCc($quoteId);
		}
	}
}
