function FraudgeniusAdminPopup(url){
	var a=700;
	var c=600;
	var viewport=getViewport();
	var f=(viewport.width/2)-(a/2);
	var e=(viewport.heightt/2)-(c/2);
	window.open(url,'Fraud Detection',"width="+a+", height="+c+", top="+e+", left="+f);
	return false
}

function getViewport()
{
	var viewPortWidth;
	var viewPortHeight;
	
	if (typeof window.innerWidth != 'undefined') 
	{
		viewPortWidth = window.innerWidth,
		viewPortHeight = window.innerHeight
	}
	else if (typeof document.documentElement != 'undefined'
	&& typeof document.documentElement.clientWidth !=
	'undefined' && document.documentElement.clientWidth != 0) 
	{
		viewPortWidth = document.documentElement.clientWidth,
		viewPortHeight = document.documentElement.clientHeight
	}
	else 
	{
		viewPortWidth = document.getElementsByTagName('body')[0].clientWidth,
		viewPortHeight = document.getElementsByTagName('body')[0].clientHeight
	}
	return [viewPortWidth, viewPortHeight];
}