<?php
namespace Fraudgenius\Fraudgenius\Observer;

use Magento\Framework\Event\ObserverInterface;

class OrderGrid implements ObserverInterface
{
    public $fraudgeniusHelper;
    public function __construct(\Fraudgenius\Fraudgenius\Helper\Data $fraudgeniusHelper)
    {
        $this->fraudgeniusHelper = $fraudgeniusHelper;
    }
	
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		echo 'OrderGrid observer'; exit;
		$obj = $observer->getEvent()->getOrderGridCollection();
		$obj->getSelect()->joinLeft(
            ['fraudgenius' => 'fraudgenius_score'],
            "(main_table.entity_id = fraudgenius.order_id)",
            [
                'fraudgenius.fraud_score as fraud_score'
            ]
        );
    }
}
