<?php
namespace Fraudgenius\Fraudgenius\Observer;

use Magento\Framework\Event\ObserverInterface;

class OrderSave implements ObserverInterface
{
    public $fraudgeniusHelper;
    public function __construct(\Fraudgenius\Fraudgenius\Helper\Data $fraudgeniusHelper)
    {
        $this->fraudgeniusHelper = $fraudgeniusHelper;
    }
	
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		try {
			$order = $observer->getEvent()->getData('order');
			if ($order && $order->getId() > 0) {
				$active = $this->fraudgeniusHelper->getStoreConfig('fraudgenius/account/active');
				if ($active) {
					$score = $this->fraudgeniusHelper->getFraudScore($order->getId());
					if ($score && $score->getId() > 0) {
					} else {
						$this->fraudgeniusHelper->saveFraudScore($order->getId());
					}
				}
			}
		} catch( \Exception $e){
			$this->fraudgeniusHelper->log($e->getMessage());
		}
    }
}
