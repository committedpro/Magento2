<?php
namespace Fraudgenius\Fraudgenius\Block\System\Config;

class Test extends \Magento\Config\Block\System\Config\Form\Field
{
	const TEST_TEMPLATE = 'system/config/test.phtml';
	
	protected function _prepareLayout()
    {
        parent::_prepareLayout();
        if (!$this->getTemplate()) {
            $this->setTemplate(static::TEST_TEMPLATE);
        }
        return $this;
    }
	
	public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $element->unsScope()->unsCanUseWebsiteValue()->unsCanUseDefaultValue();
        return parent::render($element);
    }
	
	protected function _getElementHtml(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $originalData = $element->getOriginalData();
        $this->addData(
            [
                'test_url' => $url = $this->getUrl('fraudgenius/index/test'),
                'html_id' => $element->getHtmlId()
            ]
        );
        return $this->_toHtml();
    }
}
