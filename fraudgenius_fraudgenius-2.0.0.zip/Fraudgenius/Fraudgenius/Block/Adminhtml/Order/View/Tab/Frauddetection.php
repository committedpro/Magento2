<?php
namespace Fraudgenius\Fraudgenius\Block\Adminhtml\Order\View\Tab;

class Frauddetection extends \Magento\Backend\Block\Template implements
    \Magento\Backend\Block\Widget\Tab\TabInterface
{
	protected $_coreRegistry;
 	protected $helper;
	
	public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
		\Fraudgenius\Fraudgenius\Helper\Data $helper,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
		$this->helper = $helper;
        parent::__construct($context, $data);
    }
	
    public function getOrder()
    {
        return $this->_coreRegistry->registry('current_order');
    }
	
	public function getHelper()
    {
        return $this->helper;
    }
	
	public function getPopupUrl()
    {
        return $this->getUrl('fraudgenius/index/popup', ["id" => $this->getOrder()->getId()]);
    }
	
	public function getReloadUrl()
    {
        return $this->getUrl('fraudgenius/index/reload', ["id" => $this->getOrder()->getId()]);
    }

    public function getTabLabel()
    {
        return __('Fraud Genius');
    }

    public function getTabTitle()
    {
        return __('Fraud Genius');
    }
	
	public function getTabClass()
	{
		return '';
	}

    public function canShowTab()
    {
        return true;
    }

    public function isHidden()
    {
        if ($this->helper->getStoreConfig("fraudgenius/account/active") != '1')
			return true;
		return false;
    }
}
