<?php
namespace Fraudgenius\Fraudgenius\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface
{
	public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
	{
		$installer = $setup;
		$installer->startSetup();
		
		$table = $installer->getConnection()->newTable(
            $installer->getTable('fraudgenius_score')
        )->addColumn(
            'entity_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Primary Id'
		)->addColumn(
            'order_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['unsigned' => true],
            'Order Id'
		)->addColumn(
            'fraud_score',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['unsigned' => false],
            'Fraud Score'
		)->addColumn(
            'fraud_trans_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'Fraud Trans ID'
		)->addColumn(
            'fraud_msg',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'Fraud Message'
        )->addColumn(
            'fraud_respone',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'Fraud Response'
        )->setComment(
            'Fraud Score Table'
        );
		$installer->getConnection()->createTable($table);
		
		$table = $installer->getConnection()->newTable(
            $installer->getTable('fraudgenius_raw_data')
        )->addColumn(
            'id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Primary Id'
		)->addColumn(
            'order_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['unsigned' => true],
            'Order Id'
        )->addColumn(
            'raw_data',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'Raw Data'
        )->setComment(
            'Fraud Raw Data Table'
        );
		$installer->getConnection()->createTable($table);
		
		$table = $installer->getConnection()->newTable(
            $installer->getTable('fraudgenius_temp')
        )->addColumn(
            'id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Primary Id'
		)->addColumn(
            'quote_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['unsigned' => true],
            'Quote Id'
		)->addColumn(
            'cc_number',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'CC Number'
        )->addColumn(
            'cc_owner',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'CC Owner'
        )->setComment(
            'Fraud Temp Table'
        );
		$installer->getConnection()->createTable($table);
		
		$installer->getConnection()->addColumn(
   			$installer->getTable('sales_order_grid'),
			'fraud_score',
			[
				'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				'comment' => 'Fraud Score'
			]
		);
		
		$installer->endSetup(); 
	}
}
?>