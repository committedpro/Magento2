<?php
 
namespace Toweringmedia\SliderCarouselTicker\Controller\Adminhtml;
 
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Toweringmedia\SliderCarouselTicker\Model\SliderFactory;
 
class Slider extends Action
{
    protected $_coreRegistry;

    protected $_resultPageFactory;

    protected $sliderFactory;
 
    /**
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param SliderFactory $newsFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        SliderFactory $sliderFactory
    ) {
       parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->sliderFactory = $sliderFactory;
    }
 
    /**
     * Access rights checking
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Toweringmedia_SliderCarouselTicker::slider');
    }
	
	public function execute()
	{
	 
	}
}