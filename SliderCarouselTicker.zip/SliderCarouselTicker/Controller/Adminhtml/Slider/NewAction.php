<?php
 
namespace Toweringmedia\SliderCarouselTicker\Controller\Adminhtml\Slider;
 
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\ForwardFactory;

class NewAction extends Action
{
	protected $resultForwardFactory;
 
    public function __construct(
        Context $context,
        ForwardFactory $resultForwardFactory
    ) {
       parent::__construct($context);
        $this->resultForwardFactory = $resultForwardFactory;
    }
 
    /**
     * Access rights checking
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Toweringmedia_SliderCarouselTicker::slider');
    }
	
    /**
     * @return void
     */
   public function execute()
   {
       $resultForward = $this->resultForwardFactory->create();
       return $resultForward->forward('edit');
   }
}