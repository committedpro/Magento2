<?php
 
namespace Toweringmedia\SliderCarouselTicker\Controller\Adminhtml\Slider;
 
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Toweringmedia\SliderCarouselTicker\Model\SliderFactory;
 
class Edit extends Action
{
	protected $_coreRegistry;

    protected $_resultPageFactory;

    protected $sliderFactory;
 
    /**
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param SliderFactory $newsFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        SliderFactory $sliderFactory
    ) {
       parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->sliderFactory = $sliderFactory;
    }
 
    /**
     * Access rights checking
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Toweringmedia_SliderCarouselTicker::slider');
    }
	
    /**
     * @return void
     */
   public function execute()
   {
	   $model = new \Magento\Framework\DataObject();

       $newsId = $this->getRequest()->getParam('id');
       $slider = $this->sliderFactory->create();
 		
        // Restore previously entered form data from session
        $data = $this->_session->getFormData(true);

        if (!empty($data)) {
            $model->setData($data);
        } else {
			if ($newsId) {
				$slider->load($newsId);
				if (!$slider->getId()) {
					$this->messageManager->addError(__('This slider no longer exists.'));
					$this->_redirect('*/*/');
					return;
				}
				$settings = json_decode($slider->getSettings(),true);
				$settings['identifier'] = $slider->getIdentifier();
				$settings['name'] = $slider->getName();
				$settings['status'] = $slider->getStatus();
				$settings['method'] = $slider->getMethod();
				$settings['id'] = $slider->getId();
				$model->setData($settings);
			} else {
				$settings['adaptiveHeight'] = 'false';
				$settings['responsive'] = 'false';
				$settings['pager'] = 'false';
				$settings['autoHover'] = 'false';
				$settings['captions'] = 'false';
				$model->setData($settings);
			}
		}
        $this->_coreRegistry->register('slidercarouselticker_slider', $model);
 
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_resultPageFactory->create();
        $resultPage->setActiveMenu('Toweringmedia_SliderCarouselTicker::sliders');
        $resultPage->getConfig()->getTitle()->prepend(__('Slider'));
 
        return $resultPage;
   }
}