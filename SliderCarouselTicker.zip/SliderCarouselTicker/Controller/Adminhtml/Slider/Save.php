<?php
 
namespace Toweringmedia\SliderCarouselTicker\Controller\Adminhtml\Slider;
 
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Toweringmedia\SliderCarouselTicker\Model\SliderFactory;
 
class Save extends Action
{
	protected $_coreRegistry;

    protected $_resultPageFactory;

    protected $sliderFactory;
 
    /**
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param SliderFactory $newsFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        SliderFactory $sliderFactory
    ) {
       parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->sliderFactory = $sliderFactory;
    }
 
    /**
     * Access rights checking
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Toweringmedia_SliderCarouselTicker::slider');
    }
	
    /**
     * @return void
     */
   public function execute()
   {
       $isPost = $this->getRequest()->getPost();
 
      if ($isPost) {
         $newsModel = $this->sliderFactory->create();
          $newsId = $this->getRequest()->getParam('id');
		  
		 $formData = $this->getRequest()->getParam('slider');
 
         if ($newsId) {
            $newsModel->load($newsId);
         }
		 else if(isset($formData['id']) && $formData['id'] > 0){
		 	$newsId = $formData['id'];
			$newsModel->load($newsId);
		 }

		$settings['carousel_source'] = isset($formData['carousel_source']) ? $formData['carousel_source']:'';
		$settings['product_source'] = isset($formData['product_source']) ? $formData['product_source']:'';
		$settings['width'] = $formData['width'];
		$settings['height'] = $formData['height'];
		$settings['mode'] = $formData['mode'];
		$settings['slideMargin'] = $formData['slideMargin'];
		$settings['infiniteLoop'] = $formData['infiniteLoop'];
		$settings['captions'] = $formData['captions'];
		$settings['tickerHover'] = isset($formData['tickerHover']) ? $formData['tickerHover']:'';
		$settings['adaptiveHeight'] = $formData['adaptiveHeight'];
		$settings['responsive'] = $formData['responsive'];
		$settings['pager'] = $formData['pager'];
		$settings['controls'] = $formData['controls'];
		$settings['auto'] = $formData['auto'];
		$settings['autoHover'] = $formData['autoHover'];
		$settings['speed'] = $formData['speed'];
		$settings['pause'] = $formData['pause'];
		$settings['minSlides'] = $formData['minSlides'];
		$settings['maxSlides'] = $formData['maxSlides'];
		$settings['moveSlides'] = $formData['moveSlides'];
		$settings['slideWidth'] = $formData['slideWidth'];
		
		$formData['settings'] = json_encode($settings);
		
		
         $newsModel->setData($formData);
		 
		$helper = $this->_objectManager->get('Toweringmedia\SliderCarouselTicker\Helper\Data');
         
         try {

			if ($newsId) {
				if ($newsModel->getIdentifier() != $formData['identifier']) {
					if ($helper->isSliderExist($data['identifier']) ) {
						 throw new \Magento\Framework\Validator\Exception(__('This Identifier already exist, please give unique one'));
					}
				}
			} else {
				if ($helper->isSliderExist($formData['identifier']) ) {
					 throw new \Magento\Framework\Validator\Exception(__('This Identifier already exist, please give unique one'));
				}
			}
			
			if ($formData['method'] != 1 && empty($formData['slideWidth']) ) {
				  throw new \Magento\Framework\Validator\Exception(__('Image width is required for Carousel and Ticker'));
			}

            // Save news
            $newsModel->save();
 
            // Display success message
            $this->messageManager->addSuccess(__('The slider has been saved.'));
 
            // Check if 'Save and Continue'
            if ($this->getRequest()->getParam('back')) {
               $this->_redirect('*/*/edit', ['id' => $newsModel->getId(), '_current' => true]);
               return;
            }
 
            // Go to grid page
            $this->_redirect('*/*/');
            return;
         } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
         }

         $this->_getSession()->setFormData($formData);
         $this->_redirect('*/*/edit', ['id' => $newsId]);
      }
   }
}