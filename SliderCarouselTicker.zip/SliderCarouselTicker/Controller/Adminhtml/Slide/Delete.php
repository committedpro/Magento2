<?php
 
namespace Toweringmedia\SliderCarouselTicker\Controller\Adminhtml\Slider;
 
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Toweringmedia\SliderCarouselTicker\Model\SliderFactory;
 
class Delete extends Action
{
	protected $_coreRegistry;

    protected $_resultPageFactory;

    protected $sliderFactory;
 
    /**
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param SliderFactory $newsFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        SliderFactory $sliderFactory
    ) {
       parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->sliderFactory = $sliderFactory;
    }
 
    /**
     * Access rights checking
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Toweringmedia_SliderCarouselTicker::slider');
    }
	
    /**
     * @return void
     */
   public function execute()
   {
       $newsId = (int) $this->getRequest()->getParam('id');
 
      if ($newsId) {
         /** @var $newsModel \Mageworld\SimpleNews\Model\News */
         $newsModel = $this->sliderFactory->create();
         $newsModel->load($newsId);
 
         // Check this news exists or not
         if (!$newsModel->getId()) {
            $this->messageManager->addError(__('This slider no longer exists.'));
         } else {
               try {
                  // Delete news
                  $newsModel->delete();
                  $this->messageManager->addSuccess(__('The slider has been deleted.'));
 
                  // Redirect to grid page
                  $this->_redirect('*/*/');
                  return;
               } catch (\Exception $e) {
                   $this->messageManager->addError($e->getMessage());
                   $this->_redirect('*/*/edit', ['id' => $newsModel->getId()]);
               }
         }
      }
   }
}