<?php
 
namespace Toweringmedia\SliderCarouselTicker\Controller\Adminhtml\Slide;
 
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Toweringmedia\SliderCarouselTicker\Model\SlideFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;
 
class Save extends Action
{
	protected $_coreRegistry;

    protected $_resultPageFactory;

    protected $sliderFactory;
	
	protected $_fileUploaderFactory;
	
	protected $_storeManager;
	
	protected $_filesystem;
 
    /**
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param SliderFactory $newsFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        SlideFactory $sliderFactory,
		UploaderFactory $fileUploaderFactory,
		StoreManagerInterface $storeManager,
		Filesystem $filesystem
    ) {
       parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->sliderFactory = $sliderFactory;
		$this->_fileUploaderFactory = $fileUploaderFactory;
        $this->_storeManager = $storeManager;
        $this->_filesystem = $filesystem;
    }
 
    /**
     * Access rights checking
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Toweringmedia_SliderCarouselTicker::slider');
    }
	
    /**
     * @return void
     */
   public function execute()
   {
       $isPost = $this->getRequest()->getPost();
 
      if ($isPost) {
         $model = $this->sliderFactory->create();
         $newsId = $this->getRequest()->getParam('id');
		 $slider_id = $this->getRequest()->getParam('slider_id');
 		 $formData = $this->getRequest()->getParam('slider');
         if ($newsId) {
            $model->load($newsId);
			
			$filename = $model->getType();
			if (isset($_FILES['type']['name']) && $_FILES['type']['name'] != '') {
				 try {
					 
					 $pathurl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'slidercarouselticker/';
					 $mediaDir = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
					 $mediapath = $this->_mediaBaseDirectory = rtrim($mediaDir, '/');
					 
					 $uploader = $this->_fileUploaderFactory->create(['fileId' => 'type']);
					$uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
					$uploader->setAllowRenameFiles(false);
					$uploader->setFilesDispersion(false);
					$path = $mediapath . '/slidercarouselticker/';
					$filename = md5(time().$_FILES['type']['name']).'.jpg';
					$uploader->save($path, $filename);
					 $formData['type'] = $filename;
				 } catch (Exception $e) {
					 $this->messageManager->addError(__($e->getMessage()));
					if ($model && $model->getId()) {
						$this->_redirect('*/*/edit', array('id' => $model->getId(),'slider_id'=>$slider_id));
						return;
					} else {
						$this->_redirect('*/*/new', array('slider_id'=>$slider_id));
						return;
					}
				 }                            
			} else if (empty($filename)) {
				 $this->messageManager->addError(__('Please upload image'));
				if ($model && $model->getId()) {
					$this->_redirect('*/*/edit', array('id' => $model->getId(),'slider_id'=>$slider_id));
					return;
				} else {
					$this->_redirect('*/*/new', array('slider_id'=>$slider_id));
					return;
				}
			}
         } else {
		 	if (isset($_FILES['type']['name']) && $_FILES['type']['name'] != '') {
				 try {    
					 $pathurl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'slidercarouselticker/';
					 $mediaDir = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
					 $mediapath = $this->_mediaBaseDirectory = rtrim($mediaDir, '/');
					 
					 $uploader = $this->_fileUploaderFactory->create(['fileId' => 'type']);
					$uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
					$uploader->setAllowRenameFiles(false);
					$uploader->setFilesDispersion(false);
					$path = $mediapath . '/slidercarouselticker/';
					$filename = md5(time().$_FILES['type']['name']).'.jpg';
					$uploader->save($path, $filename);
					 $formData['type'] = $filename;
				 } catch (Exception $e) {
					 $this->messageManager->addError(__($e->getMessage()));
					if ($model && $model->getId()) {
						$this->_redirect('*/*/edit', array('id' => $model->getId(),'slider_id'=>$slider_id));
						return;
					} else {
						$this->_redirect('*/*/new', array('slider_id'=>$slider_id));
						return;
					}
				 }                     
			} else {
				$this->messageManager->addError(__('Please upload image'));
				if ($model && $model->getId()) {
					$this->_redirect('*/*/edit', array('id' => $model->getId(),'slider_id'=>$slider_id));
					return;
				} else {
					$this->_redirect('*/*/new', array('slider_id'=>$slider_id));
					return;
				}
			}
		 }
		
        $model->setData($formData);

         try {
			 $model->setSliderId($slider_id);
            // Save news
            $model->save();
 
            // Display success message
            $this->messageManager->addSuccess(__('The slide has been saved.'));
 
            // Check if 'Save and Continue'
            if ($this->getRequest()->getParam('back')) {
               $this->_redirect('*/*/edit', ['id' => $model->getId(), '_current' => true,'slider_id'=>$slider_id]);
               return;
            }
 
            // Go to grid page
            $this->_redirect('*/slider/edit',['id'=>$slider_id,'active_tab'=>'slide_options']);
            return;
         } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
         }

         $this->_getSession()->setFormData($formData);
         $this->_redirect('*/*/edit', ['id' => $newsId,'slider_id'=>$slider_id]);
      }
   }
}