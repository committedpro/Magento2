<?php
 
namespace Toweringmedia\SliderCarouselTicker\Controller\Adminhtml\Slide;
 
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Toweringmedia\SliderCarouselTicker\Model\SlideFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
 
class MassDelete extends Action
{
	protected $_coreRegistry;

    protected $_resultPageFactory;

    protected $sliderFactory;
	
	protected $_filesystem;
 
    /**
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param SliderFactory $newsFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        SlideFactory $sliderFactory,
		Filesystem $filesystem
    ) {
       parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->sliderFactory = $sliderFactory;
		$this->_filesystem = $filesystem;
    }
 
    /**
     * Access rights checking
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Toweringmedia_SliderCarouselTicker::slider');
    }
	
    /**
     * @return void
     */
   public function execute()
   {
       $newsIds = $this->getRequest()->getParam('slide');
	   $slider_id = $this->getRequest()->getParam('slider_id');
 
        foreach ($newsIds as $newsId) {
            try {
                $newsModel = $this->sliderFactory->create();
                $newsModel->load($newsId)->delete();
				$filename = $newsModel->getType();
				$newsModel->delete();
				$mediaDir = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
				$mediapath = $this->_mediaBaseDirectory = rtrim($mediaDir, '/');
				$media_path = $mediapath . '/slidercarouselticker/';
				@unlink($media_path.$filename);
				$newsModel->delete();
				
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }
        }
 
        if (count($newsIds)) {
            $this->messageManager->addSuccess(
                __('A total of %1 record(s) were deleted.', count($newsIds))
            );
        }
 
        $this->_redirect('*/slider/edit',['id'=>$slider_id,'active_tab'=>'slide_options']);

   }
}