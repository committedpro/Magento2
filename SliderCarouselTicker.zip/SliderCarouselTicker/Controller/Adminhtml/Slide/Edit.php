<?php
 
namespace Toweringmedia\SliderCarouselTicker\Controller\Adminhtml\Slide;
 
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Toweringmedia\SliderCarouselTicker\Model\SlideFactory;
 
class Edit extends Action
{
	protected $_coreRegistry;

    protected $_resultPageFactory;

    protected $sliderFactory;
 
    /**
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param SliderFactory $newsFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        SlideFactory $sliderFactory
    ) {
       parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->sliderFactory = $sliderFactory;
    }
 
    /**
     * Access rights checking
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Toweringmedia_SliderCarouselTicker::slider');
    }
	
    /**
     * @return void
     */
   public function execute()
   {
		$slider_id = $this->getRequest()->getParam('slider_id');
       $newsId = $this->getRequest()->getParam('id');
       $model = $this->sliderFactory->create();
 		
        // Restore previously entered form data from session
        $data = $this->_session->getFormData(true);

        if (!empty($data)) {
            $model->setData($data);
        } else {
			if ($newsId) {
				$model->load($newsId);
				if (!$model->getId()) {
					$this->messageManager->addError(__('This slide no longer exists.'));
					$this->_redirect('*/*/');
					return;
				}
				$model->setType('');
				$model->setData($data);
			}
		}
        $this->_coreRegistry->register('slidercarouselticker_slide', $model);
 
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_resultPageFactory->create();
        $resultPage->setActiveMenu('Toweringmedia_SliderCarouselTicker::sliders');
        $resultPage->getConfig()->getTitle()->prepend(__('Slide Information'));
 
        return $resultPage;
   }
}