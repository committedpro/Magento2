<?php
 
namespace Toweringmedia\SliderCarouselTicker\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class UpdateClickCount extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        Context $context
    )
    {
        parent::__construct($context);
    }
 
    public function execute()
    {
		$slide_id = trim($this->getRequest()->getParam('slide_id'));
		$objManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objManager->get('Magento\Framework\App\ResourceConnection');
        $connection= $resource->getConnection();
        $table = $resource->getTableName('slidercarouselticker_slide');
        $query = "UPDATE {$table} SET total_impressions = total_impressions + 1 WHERE id = '{$slide_id}'";
        $connection->query($query);
		exit;
    }
}