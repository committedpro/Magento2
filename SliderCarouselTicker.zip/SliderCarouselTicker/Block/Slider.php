<?php
namespace Toweringmedia\SliderCarouselTicker\Block;


use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\View\Element\Template;
use Magento\Store\Model\StoreManagerInterface;
use Toweringmedia\SliderCarouselTicker\Helper\Data as SlideHelper;

class Slider extends Template
{
    protected $storeManager;
	protected $slideHelper;

	protected $_template='Toweringmedia_SliderCarouselTicker::slider.phtml';

    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
		SlideHelper $slideHelper,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->storeManager = $storeManager;
		$this->slideHelper = $slideHelper;
    }
	
	public function getSlider()
	{
		return $this->getData('slider');
	}
	
	public function getHelper()
	{
		return $this->slideHelper;
	}
	
	public function getSlidePath()
	{
		return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'slidercarouselticker/';
	}
}