<?php
 
namespace Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Renderer;
 
use Magento\Framework\DataObject;
use Magento\Store\Model\StoreManagerInterface;
 
class Image extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
	protected $_storeManager;
	
	public function __construct(
        StoreManagerInterface $_storeManager
    ) {
        $this->_storeManager = $_storeManager;
    }
 
    public function render(DataObject $row)
    {
		$filename =  $row->getType();
		if($filename)
		{
			$media_path = $pathurl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'slidercarouselticker/';
			$html = '<img src="'.$media_path.$filename.'" width="100px" />';
		}
		else
		{
			$html ='&nbsp;';
		}
		return $html;
    }
}
