<?php
 
namespace Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Slide\Edit;
 
use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;
use Magento\Framework\App\RequestInterface;

class Form extends Generic
{
	protected $request;
	
	public $slider_id = 0;
	public $id = 0;
	
	public function __construct(
		RequestInterface $request,
        Context $context,
		Registry $registry,
        FormFactory $formFactory,
		array $data = []

    ) {
		$this->request = $request;
		
		$slider_id = (int)$request->getParam('slider_id');
		$this->slider_id = $slider_id;
		$id = (int)$request->getParam('id');
		$this->id = $id;
		
        parent::__construct($context, $registry, $formFactory, $data);
    }
	
    /**
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            [
                'data' => [
                    'id'    => 'edit_form',
                    'action' => $this->getUrl('*/slide/save', array('slider_id'=>$this->slider_id,'id'=>$this->id)),
                    'method' => 'post',
					'enctype' => 'multipart/form-data'
                ]
            ]
        );
        $form->setUseContainer(true);
        $this->setForm($form);
 
        return parent::_prepareForm();
    }
}