<?php
 
namespace Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Slide\Edit;
 
use Magento\Backend\Block\Widget\Tabs as WidgetTabs;
 
class Tabs extends WidgetTabs
{
    /**
     * Class constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('slide_edit_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Slide Information'));
    }
 
    /**
     * @return $this
     */
    protected function _beforeToHtml()
    {
        $this->addTab(
            'slide_info',
            [
                'label' => __('Information'),
                'title' => __('Information'),
                'content' => $this->getLayout()->createBlock(
                    'Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Slide\Edit\Tab\Info'
                )->toHtml(),
                'active' => true
            ]
        );
 
        return parent::_beforeToHtml();
    }
}