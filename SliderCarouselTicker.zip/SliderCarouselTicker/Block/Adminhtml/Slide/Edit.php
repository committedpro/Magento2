<?php
 
namespace Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Slide;
 
use Magento\Backend\Block\Widget\Form\Container;
use Magento\Backend\Block\Widget\Context;
use Magento\Framework\Registry;
use Magento\Framework\App\RequestInterface;

class Edit extends Container
{
	protected $request;
	
	public $slider_id = 0;
	
   /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;
 
    /**
     * @param Context $context
     * @param Registry $registry
     * @param array $data
     */
    public function __construct(
		RequestInterface $request,
        Context $context,
        Registry $registry,
        array $data = []
    ) {
		$this->request = $request;
		
		$slider_id = (int)$request->getParam('slider_id');
		$this->slider_id = $slider_id;
		
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }
 
    /**
     * Class constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_objectId = 'id';
        $this->_controller = 'adminhtml_slide';
        $this->_blockGroup = 'Toweringmedia_SliderCarouselTicker';
 
        parent::_construct();
		
		$this->buttonList->remove('delete');
		$this->buttonList->remove('reset');
		$this->buttonList->remove('back');
 	
 		 $this->buttonList->add(
            'back',
            [
                'label' => __('Back'),
                'class' => 'back',
                'onclick' => "setLocation('" . $this->getUrl('*/slider/edit', array('id'=>$this->slider_id,'active_tab'=>'slide_options')) . "')",

            ],
            -100
        );
        $this->buttonList->update('save', 'label', __('Save'));
        $this->buttonList->add(
            'saveandcontinue',
            [
                'label' => __('Save and Continue Edit'),
                'class' => 'save',
                'data_attribute' => [
                    'mage-init' => [
                        'button' => [
                            'event' => 'saveAndContinueEdit',
                            'target' => '#edit_form'
                        ]
                    ]
                ]
            ],
            -100
        );
    }
 
    /**
     * Retrieve text for header element depending on loaded news
     * 
     * @return string
     */
    public function getHeaderText()
    {
        $newsRegistry = $this->_coreRegistry->registry('slidercarouselticker_slider');
        if ($newsRegistry->getId()) {
            $newsTitle = $this->escapeHtml($newsRegistry->getTitle());
            return __("Edit Slide '%1'", $newsTitle);
        } else {
            return __('Add Slide');
        }
    }
 
    /**
     * Prepare layout
     *
     * @return \Magento\Framework\View\Element\AbstractBlock
     */
    protected function _prepareLayout()
    {
        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('post_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'post_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'post_content');
                }
            };
        ";
 
        return parent::_prepareLayout();
    }
}