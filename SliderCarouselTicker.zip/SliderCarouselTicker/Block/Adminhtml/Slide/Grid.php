<?php
 
namespace Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Slide;
 
use Magento\Backend\Block\Widget\Grid\Extended as WidgetGrid;
use Toweringmedia\SliderCarouselTicker\Model\SlideFactory;
use Magento\Framework\App\RequestInterface;
 
class Grid extends WidgetGrid
{
   protected $slideFactory;
   
   protected $request;
   
   public $slider_id = 0;
   
   	protected $_template='Toweringmedia_SliderCarouselTicker::slide/extended.phtml';
 
	public function __construct(
		RequestInterface $request,
		\Magento\Backend\Block\Template\Context $context,
		\Magento\Backend\Helper\Data $backendHelper,
		SlideFactory $slideFactory,
		\Magento\Framework\Registry $coreRegistry,
		array $data = []
	) {
		$this->request = $request;
		$this->slideFactory = $slideFactory;
		$this->_coreRegistry = $coreRegistry;
		
		$slider_id = (int)$request->getParam('id');
		$this->slider_id = $slider_id;
		
		parent::__construct($context, $backendHelper, $data);
		
		$this->setId('slidercarouselticker_slide_grid');
		$this->setDefaultSort('id');
		$this->setDefaultDir('ASC');
		$this->setFilterVisibility(false);
		$this->setSaveParametersInSession(true);
	}
	
	public function getSliderId()
	{
		return $this->slider_id;
	}
	
	public function getPagerVisibility()
	{
		return false;
	}

	/**
	 * @return Grid
	 */
	protected function _prepareCollection()
	{
		$collection = $this->slideFactory->create()->getCollection();
		$collection
				->getSelect()
				->where('main_table.slider_id='.$this->slider_id);
		$this->setCollection($collection);
		$this->setCollection($collection);
		return parent::_prepareCollection();
	}
	
	/**
	 * @return Extended
	 */
	protected function _prepareColumns()
	{
		$this->addColumn(
			'type',
			[
				'header' => __('Image'),
				'sortable' => false,
				'filter' => false,
				'index' => 'type',
				'renderer'  => '\Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Renderer\Image'
			]
		);
		$this->addColumn(
			'title',
			[
				'header' => __('Title'),
				'index' => 'title',
				'filter' => false,
				'sortable' => false,
			]
		);
		$this->addColumn(
			'url',
			[
				'header' => __('Url'),
				'index' => 'url',
				'filter' => false,
				'sortable' => false,
			]
		);
		$this->addColumn(
			'total_impressions',
			[
				'header' => __('Total Impressions'),
				'index' => 'total_impressions',
				'align' => 'center',
				'filter' => false,
				'sortable' => false,
			]
		);
		$this->addColumn(
			'sort_order',
			[
				'header' => __('Sort Order'),
				'index' => 'sort_order',
				'align' => 'center',
				'filter' => false,
				'sortable' => false,
			]
		);
		
		$this->addColumn(
			'status',
			[
				'header' => __('Status'),
				'index' => 'status',
				'align' => 'center',
           		'width' => '30px',
				'filter' => false,
				'sortable' => false,
				'type' => 'options',
				'options' => [1 => 'Enabled',2 => 'Disabled'],
			]
		);
		
		$this->addColumn(
			'action',
			[
				'header' => __('Action'),
				'width' => '30px',
				'align' => 'center',
				'index' => 'stores',
				'getter' => 'getId',
				'is_system' => true,
				'filter' => false,
				'sortable' => false,
				'type' => 'action',
				'actions' => array(
					array(
						'caption' => __('Edit'),
						'url' => array('base' => '*/slide/edit', 'params'=>array('slider_id'=>$this->slider_id)),
						'field' => 'id'
					)
				),
			]
		);
	
		return parent::_prepareColumns();
	}
	
	protected function _prepareMassaction()
    {
		
        $this->setMassactionIdField('id');
        $this->getMassactionBlock()->setFormFieldName('slide');

        $this->getMassactionBlock()->addItem('delete', array(
             'label'=> __('Delete'),
             'url'  => $this->getUrl('*/slide/massDelete', array('slider_id'=>$this->slider_id)),
             'confirm' => __('Are you sure?')
        ));

        return $this;
    }
}