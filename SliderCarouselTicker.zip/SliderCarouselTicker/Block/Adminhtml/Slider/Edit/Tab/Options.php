<?php
 
namespace Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Slider\Edit\Tab;
 
use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;
use Magento\Cms\Model\Wysiwyg\Config;
use Toweringmedia\SliderCarouselTicker\Model\Status;
use Toweringmedia\SliderCarouselTicker\Model\Methods;
use Toweringmedia\SliderCarouselTicker\Helper\Data as SliderHelper;

class Options extends Generic implements TabInterface
{
    /**
     * @var \Magento\Cms\Model\Wysiwyg\Config
     */
    protected $_wysiwygConfig;
 
    /**
     * @var \Tutorial\SimpleNews\Model\Config\Status
     */
    protected $_newsStatus;
	
	protected $methods;
	
	protected $sliderHelper;
 
   /**
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param Config $wysiwygConfig
     * @param Status $newsStatus
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        Config $wysiwygConfig,
        Status $newsStatus,
		Methods $methods,
		SliderHelper $sliderHelper,
        array $data = []
    ) {
        $this->_wysiwygConfig = $wysiwygConfig;
        $this->_newsStatus = $newsStatus;
		$this->methods = $methods;
		$this->sliderHelper = $sliderHelper;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Prepare form fields
     *
     * @return \Magento\Backend\Block\Widget\Form
     */
    protected function _prepareForm()
    {
       /** @var $model \Tutorial\SimpleNews\Model\News */
        $model = $this->_coreRegistry->registry('slidercarouselticker_slider');
 
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('slider_');
        $form->setFieldNameSuffix('slider');
		$htmlIdPrefix = $form->getHtmlIdPrefix();
		
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Options')]
        );
 
		$fieldset->addField(
            'method',
            'select',
            [
                'name'      => 'method',
                'label'     => __('Type'),
                'options'   => $this->methods->getOptionArray()
            ]
        );
		
		$fieldset->addField(
            'carousel_source',
            'select',
            [
                'name'      => 'carousel_source',
                'label'     => __('Image Source'),
                'options'   => ['1' => __('Manually Added Images'),'2' => __('Pull Products From Category')]
            ]
        );
		
		$fieldset->addField(
            'product_source',
            'select',
            [
                'name'      => 'product_source',
                'label'     => __('Select Category'),
                'options'   =>  $this->sliderHelper->getAllCategoriesArray(true)
            ]
        );
		
        $fieldset->addField(
            'width',
            'text',
            [
                'name'        => 'width',
                'label'    => __('Slider Width'),
				'class' => 'required-entry validate-greater-than-zero validate-number validate-digits',
                'required'     => true
            ]
        );
		
		$fieldset->addField(
            'height',
            'text',
            [
                'name'        => 'height',
                'label'    => __('Slider Height'),
				'class' => 'required-entry validate-greater-than-zero validate-number validate-digits',
                'required'     => true
            ]
        );
		
		$fieldset->addField(
            'mode',
            'select',
            [
                'name'      => 'mode',
                'label'     => __('Mode'),
                'options'   => ['1' => __('Horizantal'),'2' => __('Vertical'),'3' => __('Fade')],
				'note' => __('Type of transition between images')
            ]
        );
		
		$fieldset->addField(
            'slideWidth',
            'text',
            [
                'name'        => 'slideWidth',
                'label'    => __('Image Width'),
				'class' => 'validate-greater-than-zero validate-number validate-digits',
				'note' => '<span style="color:red; font-weight:bold">The width of each image. This setting is required if slider type choosen is "Carousel" or "Ticker"</span>'
            ]
        );
		
		$fieldset->addField(
            'slideMargin',
            'text',
            [
                'name'        => 'slideMargin',
                'label'    => __('Image Margin'),
                'class' => 'validate-greater-than-zero validate-number validate-digits',
				'note' => 'Margin between each image.'
            ]
        );
		
		$fieldset->addField(
            'infiniteLoop',
            'select',
            [
                'name'      => 'infiniteLoop',
                'label'     => __('Infinite Loop'),
                'options'   => ['true' => __('Yes'),'false' => __('No')],
				'note' => __('If true, clicking "Next" while on the last image will transition to the first slide and vice-versa.')
            ]
        );
		
		$fieldset->addField(
            'captions',
            'select',
            [
                'name'      => 'captions',
                'label'     => __('Captions'),
                'options'   => ['true' => __('Yes'),'false' => __('No')],
				'note' => __('Include image captions')
            ]
        );
		
		$fieldset->addField(
            'tickerHover',
            'select',
            [
                'name'      => 'tickerHover',
                'label'     => __('Ticker Hover'),
                'options'   => ['true' => __('Yes'),'false' => __('No')],
				'note' => __('Ticker will pause when mouse hovers over slider.')
            ]
        );
		
		$fieldset->addField(
            'adaptiveHeight',
            'select',
            [
                'name'      => 'adaptiveHeight',
                'label'     => __('Adaptive Height'),
                'options'   => ['true' => __('Yes'),'false' => __('No')],
				'note' => __('Dynamically adjust slider height based on each image\'s height')
            ]
        );
		
		$fieldset->addField(
            'responsive',
            'select',
            [
                'name'      => 'responsive',
                'label'     => __('Responsive'),
                'options'   => ['true' => __('Yes'),'false' => __('No')],
				'note' => __('Enable or disable auto resize of the slider. Useful if you need to use fixed width sliders.')
            ]
        );
		
		$fieldset->addField(
            'pager',
            'select',
            [
                'name'      => 'pager',
                'label'     => __('Pager'),
                'options'   => ['true' => __('Yes'),'false' => __('No')],
				'note' => __('If true, a pager will be added')
            ]
        );
		
		$fieldset->addField(
            'controls',
            'select',
            [
                'name'      => 'controls',
                'label'     => __('Controls'),
                'options'   => ['true' => __('Yes'),'false' => __('No')],
				'note' => __('If true, "Next" / "Prev" controls will be added')
            ]
        );
		
		$fieldset->addField(
            'auto',
            'select',
            [
                'name'      => 'auto',
                'label'     => __('Auto Transition'),
                'options'   => ['true' => __('Yes'),'false' => __('No')],
				'note' => __('Images will automatically transition')
            ]
        );
		
		$fieldset->addField(
            'autoHover',
            'select',
            [
                'name'      => 'autoHover',
                'label'     => __('Auto Hover'),
                'options'   => ['true' => __('Yes'),'false' => __('No')],
				'note' => __('Auto show will pause when mouse hovers over slider')
            ]
        );
		
		$fieldset->addField(
            'speed',
            'text',
            [
                'name'        => 'speed',
                'label'    => __('Speed'),
				'class' => 'validate-greater-than-zero validate-number validate-digits',
				'note' => 'Image transition duration (in ms), if not given 5000 assumed.'
            ]
        );
		
		$fieldset->addField(
            'pause',
            'text',
            [
                'name'        => 'pause',
                'label'    => __('Pause'),
				'class' => 'validate-greater-than-zero validate-number validate-digits',
				'note' => 'The amount of time (in ms) between each auto transition, if not given 4000 assumed.'
            ]
        );
		
		$fieldset->addField(
            'minSlides',
            'text',
            [
                'name'        => 'minSlides',
                'label'    => __('Min Images'),
				'class' => 'validate-greater-than-zero validate-number validate-digits',
				'note' => 'The minimum number of images to be shown. Images will be sized down if carousel becomes smaller than the original size.'
            ]
        );
		
		$fieldset->addField(
            'maxSlides',
            'text',
            [
                'name'        => 'maxSlides',
                'label'    => __('Max Images'),
				'class' => 'validate-greater-than-zero validate-number validate-digits',
				'note' => 'The maximum number of images to be shown. Images will be sized up if carousel becomes larger than the original size'
            ]
        );
		
		$fieldset->addField(
            'moveSlides',
            'text',
            [
                'name'        => 'moveSlides',
                'label'    => __('Move Images'),
				'class' => 'validate-greater-than-zero validate-number validate-digits',
				'note' => 'The number of images to move on transition. This value must be >= minSlides, and <= maxSlides. If zero (default), the number of fully-visible images will be used.'
            ]
        );
		
		$this->setChild(
			'form_after',
			$this->getLayout()->createBlock(
				'Magento\Backend\Block\Widget\Form\Element\Dependence'
			)->addFieldMap(
				"{$htmlIdPrefix}tickerHover",
				'tickerHover'
			)
			->addFieldMap(
				"{$htmlIdPrefix}method",
				'method'
			)
			->addFieldMap(
				"{$htmlIdPrefix}product_source",
				'product_source'
			)
			->addFieldMap(
				"{$htmlIdPrefix}carousel_source",
				'carousel_source'
			)
			->addFieldDependence(
				'tickerHover',
				'method',
				'3'
			)
			->addFieldDependence(
				'carousel_source',
				'method',
				'2'
			)
			->addFieldDependence(
				'product_source',
				'carousel_source',
				'2'
			)
		);
		
        $data = $model->getData();
        $form->setValues($data);
        $this->setForm($form);
		
        return parent::_prepareForm();
    }
 
    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('General Info');
    }
 
    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('General Info');
    }
 
    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }
 
    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }
}