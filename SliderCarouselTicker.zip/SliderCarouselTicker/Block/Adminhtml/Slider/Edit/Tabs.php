<?php
 
namespace Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Slider\Edit;
 
use Magento\Backend\Block\Widget\Tabs as WidgetTabs;
 
class Tabs extends WidgetTabs
{
    /**
     * Class constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('slider_edit_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Slider Information'));
    }
 
    /**
     * @return $this
     */
    protected function _beforeToHtml()
    {
        $this->addTab(
            'slider_info',
            [
                'label' => __('General'),
                'title' => __('General'),
                'content' => $this->getLayout()->createBlock(
                    'Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Slider\Edit\Tab\Info'
                )->toHtml(),
                'active' => true
            ]
        );
		
		$this->addTab(
            'slider_options',
            [
                'label' => __('Options'),
                'title' => __('Options'),
                'content' => $this->getLayout()->createBlock(
                    'Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Slider\Edit\Tab\Options'
                )->toHtml(),
                'active' => false
            ]
        );
		
		$this->addTab(
            'slide_options',
            [
                'label' => __('Manage Images'),
                'title' => __('Manage Images'),
                'content' => $this->getLayout()->createBlock(
                    'Toweringmedia\SliderCarouselTicker\Block\Adminhtml\Slide'
                )->toHtml(),
                'active' => false
            ]
        );
 
        return parent::_beforeToHtml();
    }
}