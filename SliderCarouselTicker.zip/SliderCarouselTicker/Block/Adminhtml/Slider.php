<?php
 
namespace Toweringmedia\SliderCarouselTicker\Block\Adminhtml;
 
use Magento\Backend\Block\Widget\Grid\Container;
 
class Slider extends Container
{
   /**
     * Constructor
     *
     * @return void
     */
   protected function _construct()
    {
        $this->_controller = 'adminhtml_slider';
        $this->_blockGroup = 'Toweringmedia_SliderCarouselTicker';
        $this->_headerText = __('Manage Sliders');
        $this->_addButtonLabel = __('Add Slider');
        parent::_construct();
    }
}