<?php
 
namespace Toweringmedia\SliderCarouselTicker\Block\Adminhtml;
 
use Magento\Backend\Block\Widget\Grid\Container;
 
class Slide extends Container
{
   /**
     * Constructor
     *
     * @return void
     */
   protected function _construct()
    {
        $this->_controller = 'adminhtml_slide';
        $this->_blockGroup = 'Toweringmedia_SliderCarouselTicker';
        $this->_headerText = __('Manage Images');
	
        parent::_construct();
    }
}