<?php
namespace Toweringmedia\SliderCarouselTicker\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Slider extends AbstractDb
{
	protected function _construct()
	{
		$this->_init('slidercarouselticker_slider', 'id');
	}
}