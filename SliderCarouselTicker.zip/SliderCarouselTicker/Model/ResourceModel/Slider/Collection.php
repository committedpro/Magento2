<?php

namespace Toweringmedia\SliderCarouselTicker\Model\ResourceModel\Slider;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
	protected function _construct()
	{
		$this->_init('Toweringmedia\SliderCarouselTicker\Model\Slider', 'Toweringmedia\SliderCarouselTicker\Model\ResourceModel\Slider');
	}
}