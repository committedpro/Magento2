<?php

namespace Toweringmedia\SliderCarouselTicker\Model\ResourceModel\Slide;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
	protected function _construct()
	{
		$this->_init('Toweringmedia\SliderCarouselTicker\Model\Slide', 'Toweringmedia\SliderCarouselTicker\Model\ResourceModel\Slide');
	}
}