<?php
namespace Toweringmedia\SliderCarouselTicker\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Magento\Catalog\Helper\Category;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Model\ProductFactory;
use Magento\Framework\Pricing\Helper\Data as PriceHelper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	protected $categoryCollectionFactory;
    protected $categoryHelper;
	protected $productCollectionFactory;
	protected $categoryFactory;
	protected $productFactory;
	protected $priceHelper;
	
    public function __construct(
		Context $context,
		CollectionFactory $categoryCollectionFactory,
        Category $categoryHelper,
		ProductCollectionFactory $productCollectionFactory,
		CategoryFactory $categoryFactory,
		ProductFactory $productFactory,
		PriceHelper $priceHelper
	)
    {
        parent::__construct($context);
		$this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->categoryHelper = $categoryHelper;
		$this->productCollectionFactory = $productCollectionFactory;
		$this->categoryFactory = $categoryFactory;
		$this->productFactory = $productFactory;
		$this->priceHelper = $priceHelper;
    }
    public function getStoreConfig($path)
    {
        return $this->scopeConfig->getValue(
            $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
	public function isSliderExist($identifier)
	{
		$objManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objManager->get('Magento\Framework\App\ResourceConnection');
        $connection= $resource->getConnection();
        $table = $resource->getTableName('slidercarouselticker_slider');
        $query = "SELECT id FROM {$table} WHERE identifier = '{$identifier}'";
        return (int)($connection->fetchOne($query));
	}
	public function getSlide($slider_id)
	{
		$objManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objManager->get('Magento\Framework\App\ResourceConnection');
        $connection= $resource->getConnection();
        $table = $resource->getTableName('slidercarouselticker_slider');
        $query = "select * from {$table} where id = '{$slider_id}'";
        return $connection->fetchRow($query);
	}
	public function getSlides($slider_id)
	{
		$objManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objManager->get('Magento\Framework\App\ResourceConnection');
        $connection= $resource->getConnection();
        $table = $resource->getTableName('slidercarouselticker_slide');
        $query = "SELECT * FROM {$table} WHERE status = 1 AND slider_id = '{$slider_id}' ORDER BY sort_order";
        return $connection->fetchAll($query);
	}
	
	public function getAllCategoriesArray($optionList = false)
	{
		$collection = $this->categoryCollectionFactory->create();
        $collection->addAttributeToSelect('*');        
        $collection->addIsActiveFilter();
        $categoriesArray = $collection->toArray();

		if (!$optionList) {
			return $categoriesArray;
		}
		
		$categories[''] = 'Select';
	 
		foreach ($categoriesArray as $categoryId => $category) 
		{
			if (isset($category['name'])) 
			{
				$paths = explode('/',$category['path']);
				$categories[$categoryId] = str_repeat("- -",count($paths)-2).' '.$category['name'];
			}
		}
	 
		return $categories;
	}
	
	public function getCategoryProducts($category_id)
	{
		$collection = $this->productCollectionFactory->create();
		$category =  $this->categoryFactory->create()->load($category_id);
		$collection->addAttributeToSelect('*');
		$collection->addCategoryFilter($category);
		$collection->addAttributeToFilter('visibility', \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH);
		$collection->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);
		$collection->getSelect()->orderRand();
		$collection->getSelect()->limit(10);
		return $collection;
	}
	
	public function getProductPrice($product)
	{
		$typeId = $product->getTypeId();
		if($typeId == 'grouped')
		{
			$prices = $this->prepareGroupedProductPrice($product);
			if(is_array($prices) && count($prices) > 0)
			{
				$price = $prices[0];
			}
			if(!$price)
			{
				$price = $product->getPrice();
			}
		}
		else
		{
			$price = $product->getPrice();
			
		}
		return $this->priceHelper->currency($price, true, false);
	}
	
	public function prepareGroupedProductPrice($groupedProduct)
	{
		$aProductIds = $groupedProduct->getTypeInstance()->getChildrenIds($groupedProduct->getId());
		
		$prices = array();
		foreach ($aProductIds as $ids) {
			foreach ($ids as $id) {
				try{
					$aProduct = $this->productFactory->create()->load($id);
					$prices[] = $aProduct->getPriceModel()->getPrice($aProduct);
				}
				catch(Exception $e)
				{
					;
				}
			}
		}
		
		sort($prices);
		return $prices;
	} 
}
