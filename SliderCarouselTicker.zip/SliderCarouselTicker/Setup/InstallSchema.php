<?php
namespace Toweringmedia\SliderCarouselTicker\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface
{
	public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
	{
		$installer = $setup;
		$installer->startSetup();
		
		$table = $installer->getConnection()->newTable(
            $installer->getTable('slidercarouselticker_slider')
        )->addColumn(
            'id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Primary Id'
		)->addColumn(
            'identifier',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'Identifier'
		)->addColumn(
            'name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'Name'
		)->addColumn(
            'method',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'Method'
		)->addColumn(
            'settings',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'Settings'
        )->addColumn(
            'status',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
           ['unsigned' => true],
            'Status'
        )->setComment(
            'Slider Table'
        );
		$installer->getConnection()->createTable($table);
		
		$table = $installer->getConnection()->newTable(
            $installer->getTable('slidercarouselticker_slide')
        )->addColumn(
            'id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Primary Id'
		)->addColumn(
            'slider_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['unsigned' => true],
            'Slider Id'
		 )->addColumn(
            'status',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
           ['unsigned' => true],
            'Status'
		 )->addColumn(
            'total_impressions',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
           ['unsigned' => true,'nullable' => false,'default' => '0'],
            'Total Impressions'
		 )->addColumn(
            'unique_impressions',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
           ['unsigned' => true,'nullable' => false,'default' => '0'],
            'Unique Impressions'
		 )->addColumn(
            'sort_order',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
           ['unsigned' => true,'nullable' => false,'default' => '0'],
            'Sort Order'
        )->addColumn(
            'type',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'Type'
		)->addColumn(
            'url',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'Url'
		)->addColumn(
            'title',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [],
            'Title'
        )->setComment(
            'Slides Table'
        );
		$installer->getConnection()->createTable($table);
		
		$installer->endSetup(); 
	}
}
?>